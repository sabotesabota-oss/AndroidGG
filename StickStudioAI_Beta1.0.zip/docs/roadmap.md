# Roadmap — Stick Studio AI

## Curto prazo
- Transcrição de áudio real (API de fala-para-texto).
- Detecção de personagens/cenários/objetos por IA real (ver pasta `ai/`), em vez de regex/palavras-chave.
- Reordenar cenas por arrastar (hoje é por botões ⬆/⬇).

## Médio prazo
- Suporte a mais de uma imagem por cena (variações), com seleção da melhor.
- Templates de prompt por estilo de vídeo (ex.: institucional, humor, storytelling).
- Fila de geração: marcar quais prompts já foram usados em qual ferramenta de IA (Meta AI, Vibes, Flow), com histórico.

## Longo prazo
- Avaliação como produto: multiusuário, sincronização em nuvem, exportação direta para o CapCut via automação (sem precisar do `.zip` manual).
