# Arquitetura — Stick Studio AI

PWA 100% front-end (sem servidor), em JavaScript puro (sem framework, sem build step). Todo o estado é salvo no IndexedDB do navegador.

## Pastas

- `js/core/` — banco de dados, navegação, interface (modal/toast/loading), utilitários, inicialização.
- `js/project/` — projetos, áudios, roteiro.
- `js/director/` — o "Diretor IA": transcrição, cenas, timeline, personagens, cenários, objetos, prompts.
- `js/editor/` — storyboard (anexar imagens às cenas) e exportação (prompts, CapCut, backup).
- `js/vendor/` — código de terceiros vendorizado (aqui, um gerador de `.zip` em JS puro, sem dependências).
- `ai/` — reservado para uma futura versão que use IA real (hoje o app usa heurísticas simples: regex e listas de palavras-chave). Veja o cabeçalho de cada arquivo.

## Banco de dados (IndexedDB, `StickStudioAI`, versão 3)

- `projects` — um registro por projeto. Guarda também o roteiro (`storyText`/`storySource`) e a transcrição (`transcriptionText`) diretamente no registro do projeto.
- `audios` — arquivos de áudio importados (indexado por `projectId`).
- `images` — imagens anexadas a cada cena no Storyboard (indexado por `projectId`).
- `metadata` — armazenamento livre chave/valor. É aqui que `js/core/project-data.js` guarda, por projeto, as listas de cenas, personagens, cenários, objetos e prompts (chaves como `scenes:<projectId>`), evitando remapear os IDs internos de cada módulo para o esquema de `autoIncrement` do IndexedDB.
- `settings`, `transcriptions`, `scenes`, `characters`, `locations`, `objects`, `prompts`, `queue` — criados pelo `database-upgrade.js` original para uso futuro por item (um registro por cena/personagem/etc). Não são usados hoje; a versão atual usa `metadata` para simplificar. Ficam reservados para uma eventual migração.

## Fluxo principal

1. **Projetos** → criar/abrir um projeto.
2. **Roteiro** → escrever manualmente, ou **Áudios** → importar e marcar um áudio principal → colar/transcrever (simulado) o texto.
3. **Diretor IA** → "Analisar Projeto": divide em cenas, detecta personagens/cenários/objetos, monta um prompt por cena e calcula a timeline. Tudo é salvo automaticamente.
4. Editar os detalhes de personagens/cenários/objetos (aparência, estilo) nas telas dedicadas — isso enriquece os prompts. Clicar em "Atualizar Prompts" para regerar sem precisar reanalisar tudo (prompts editados manualmente na mão não são sobrescritos).
5. Gerar as imagens de cada prompt nas ferramentas externas (Meta AI, Vibes, Flow etc.) e anexar em **Storyboard**.
6. **Storyboard** → exportar `.zip` para o CapCut (imagens renomeadas na ordem da timeline + manifesto com os tempos de cada cena).

## Limitações conhecidas

- A extração de personagens/cenários/objetos é feita por regras simples (palavra capitalizada / lista de palavras-chave), não por IA real — funciona bem para roteiros simples em português, mas erra em nomes incomuns ou cenários fora da lista. Ver pasta `ai/` para a direção de evolução.
- A transcrição automática de áudio é simulada (não chama nenhuma API real). Use a opção de colar a transcrição manualmente.
- Sem sincronização entre dispositivos: tudo fica salvo apenas no navegador/dispositivo atual. Use os backups `.json` para migrar ou proteger o trabalho.
