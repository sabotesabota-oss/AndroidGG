# Changelog — Stick Studio AI

## Beta 1.0 (definitivo)

**Correções**
- Corrigido bug que impedia a Timeline de ser gerada automaticamente após a análise (`Timeline.generate` não existia; o Diretor chamava um método inexistente).
- Corrigido o Roteiro, a Transcrição, as Cenas, os Personagens, Cenários, Objetos e Prompts, que eram perdidos ao atualizar a página ou trocar de projeto (nada disso era salvo no banco — só existia na memória).
- Corrigido o dashboard, que nunca atualizava a contagem de imagens.
- Corrigido `AudioManager`, que não recarregava a lista de áudios ao trocar de projeto.
- Corrigidas as páginas "Personagens", "Cenários", "Objetos" e "Prompts" do menu lateral, que existiam mas nunca eram preenchidas (só o painel resumido da tela Diretor IA funcionava).
- Corrigido `manifest.json` (sem ícones) e `service-worker.js` (referenciava arquivos que não existiam no projeto e nunca era registrado).

**Novidades**
- Personagens, cenários e objetos agora podem ser editados (descrição, aparência, estilo) — e essas descrições passam a entrar de fato no prompt final de cada cena, para manter consistência visual entre gerações de imagem.
- Cenas podem ser criadas manualmente, editadas, reordenadas e ter a duração ajustada na tela Timeline.
- Nova tela **Storyboard**: anexe a imagem gerada (Meta AI, Vibes, Flow etc.) a cada cena.
- Exportação de prompts em `.txt`.
- Exportação para CapCut em `.zip` (imagens renomeadas na ordem da timeline + manifesto + prompts).
- Backup e restauração completa do projeto em `.json` (inclui imagens).
- Botão para apagar todos os dados do dispositivo.
- Transcrição manual: cole o texto transcrito de outra ferramenta enquanto a transcrição automática real não existe.
- Toasts e tela de carregamento visuais (antes só apareciam no console).
- Ícones reais do app (PWA instalável).

## Alpha 0.5 (versão original recebida para análise)
Núcleo funcional: projetos, áudios, roteiro manual, detecção de cenas/personagens/cenários/objetos por heurística simples, geração de prompt básico por cena.
