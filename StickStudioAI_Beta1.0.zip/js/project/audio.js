/* =====================================================
   Stick Studio AI
   audio.js
   Gerenciador de Áudios
===================================================== */

const AudioManager = {

    player: null,
    input: null,
    listElement: null,

    audios: [],

    currentAudio: null,

    init() {

        this.player = document.getElementById("audioPlayer");

        this.input = document.getElementById("audioInput");

        this.listElement = document.getElementById("audioList");

        this.bindButtons();

    },

    bindButtons() {

        const importButton =
            document.getElementById("importAudio");

        if (importButton) {

            importButton.onclick = () => {

                if (!Projects.current) {

                    alert("Abra um projeto primeiro.");

                    return;

                }

                this.input.click();

            };

        }

        if (this.input) {

            this.input.onchange = (event) => {

                const file = event.target.files[0];

                if (!file) return;

                if (!Utils.isAudio(file)) {

                    alert("Arquivo inválido.");

                    return;

                }

                this.import(file);

                this.input.value = "";

            };

        }

    },

    import(file) {

        UI.showLoading("Importando áudio...");

        const audio = new Audio();

        audio.preload = "metadata";

        audio.src = URL.createObjectURL(file);

        audio.onloadedmetadata = () => {

            const data = {

                projectId: Projects.current.id,

                name: file.name,

                blob: file,

                size: file.size,

                duration: audio.duration,

                type: file.type,

                created: new Date().toISOString(),

                main: false

            };

            const store = Database.transaction(

                "audios",

                "readwrite"

            );

            store.add(data);

            store.transaction.oncomplete = () => {

                URL.revokeObjectURL(audio.src);

                UI.hideLoading();

                UI.toast("Áudio importado.");

                this.load();

            };

        };

    },

    load() {

        if (!this.listElement) return;

        if (!Projects.current) {

            this.render([]);

            return;

        }

        const store = Database.transaction("audios");

        const index = store.index("projectId");

        const request = index.getAll(

            Projects.current.id

        );

        request.onsuccess = () => {

            this.audios = request.result;

            this.render(this.audios);

            UI.updateDashboard();

        };

    },
    render(list) {

        if (!this.listElement) return;

        this.listElement.innerHTML = "";

        if (list.length === 0) {

            this.listElement.innerHTML = `

                <div class="emptyAudio">

                    <strong>Nenhum áudio.</strong>

                    <small>

                        Importe um áudio para começar.

                    </small>

                </div>

            `;

            return;

        }

        list.sort((a, b) => {

            if (a.main && !b.main) return -1;

            if (!a.main && b.main) return 1;

            return 0;

        });

        list.forEach(audio => {

            this.createCard(audio);

        });

    },

    createCard(audio) {

        const card = document.createElement("div");

        card.className = "audioItem fadeIn";

        if (audio.main) {

            card.classList.add("mainAudio");

        }

        const size = Utils.formatBytes(audio.size);

        const duration = Utils.formatTime(audio.duration);

        const date = Utils.formatDate(audio.created);

        card.innerHTML = `

            <div class="audioTop">

                <div class="audioLeft">

                    <div class="audioIcon">

                        🎵

                    </div>

                    <div class="audioInfo">

                        <div class="audioName">

                            ${audio.name}

                        </div>

                        <div class="audioSize">

                            ${size}

                        </div>

                        <div class="audioDuration">

                            ⏱ ${duration}

                        </div>

                        <div class="audioDate">

                            📅 ${date}

                        </div>

                        ${audio.main ?

                        `<div class="audioMain">

                            ⭐ Áudio Principal

                        </div>`

                        : ""}

                    </div>

                </div>

                <div class="audioButtons">

                    <button class="audioPlay">

                        ▶

                    </button>

                    <button class="audioRename">

                        ✏

                    </button>

                    <button class="audioMainBtn">

                        ⭐

                    </button>

                    <button class="audioDelete">

                        🗑

                    </button>

                </div>

            </div>

        `;

        card.querySelector(".audioPlay")

            .onclick = () => {

                this.play(audio);

            };

        card.querySelector(".audioRename")

            .onclick = () => {

                this.rename(audio.id);

            };

        card.querySelector(".audioMainBtn")

            .onclick = () => {

                this.setMain(audio.id);

            };

        card.querySelector(".audioDelete")

            .onclick = () => {

                this.remove(audio.id);

            };

        this.listElement.appendChild(card);

    },
    play(audio) {

        if (!audio || !audio.blob) return;

        if (this.player.src) {

            URL.revokeObjectURL(this.player.src);

        }

        this.currentAudio = audio;

        this.player.src = URL.createObjectURL(audio.blob);

        this.player.style.display = "block";

        this.player.play();

    },

    rename(id) {

        const audio = this.audios.find(a => a.id === id);

        if (!audio) return;

        const newName = prompt(
            "Novo nome do áudio:",
            audio.name
        );

        if (!newName) return;

        audio.name = newName;

        const store = Database.transaction(
            "audios",
            "readwrite"
        );

        store.put(audio);

        store.transaction.oncomplete = () => {

            UI.toast("Áudio renomeado.");

            this.load();

        };

    },

    setMain(id) {

        const store = Database.transaction(
            "audios",
            "readwrite"
        );

        this.audios.forEach(audio => {

            audio.main = (audio.id === id);

            store.put(audio);

        });

        store.transaction.oncomplete = () => {

            UI.toast("Áudio principal definido.");

            this.load();

        };

    },

    remove(id) {

        const audio = this.audios.find(a => a.id === id);

        if (!audio) return;

        if (!confirm(

            `Excluir "${audio.name}"?`

        )) {

            return;

        }

        const store = Database.transaction(
            "audios",
            "readwrite"
        );

        store.delete(id);

        store.transaction.oncomplete = () => {

            if (

                this.currentAudio &&

                this.currentAudio.id === id

            ) {

                this.player.pause();

                this.player.removeAttribute("src");

                this.player.style.display = "none";

                this.currentAudio = null;

            }

            UI.toast("Áudio removido.");

            this.load();

        };

    },

    stop() {

        if (!this.player) return;

        this.player.pause();

        this.player.currentTime = 0;

    },

    pause() {

        if (!this.player) return;

        this.player.pause();

    },

    resume() {

        if (!this.player) return;

        this.player.play();

    },
    getMainAudio() {

        return this.audios.find(audio => audio.main);

    },

    getById(id) {

        return this.audios.find(audio => audio.id === id);

    },

    totalDuration() {

        return this.audios.reduce((total, audio) => {

            return total + (audio.duration || 0);

        }, 0);

    },

    totalSize() {

        return this.audios.reduce((total, audio) => {

            return total + (audio.size || 0);

        }, 0);

    },

    count() {

        return this.audios.length;

    },

    saveLastAudio(id) {

        localStorage.setItem(

            "lastAudio",

            id

        );

    },

    loadLastAudio() {

        const id = Number(

            localStorage.getItem(

                "lastAudio"

            )

        );

        if (!id) return;

        const audio = this.getById(id);

        if (audio) {

            this.currentAudio = audio;

        }

    },

    updateDashboard() {

        const count = document.getElementById(

            "audioCount"

        );

        if (count) {

            count.textContent = this.count();

        }

    },

    refresh() {

        this.load();

        this.updateDashboard();

    },

    clearPlayer() {

        if (!this.player) return;

        this.player.pause();

        this.player.removeAttribute("src");

        this.player.load();

        this.player.style.display = "none";

        this.currentAudio = null;

    }

};