/* =====================================================
   Stick Studio AI
   story.js
   Gerenciador de História
===================================================== */

const Story = {

    source: "manual",

    text: "",

    audio: null,

    setSource(source) {

        this.source = source;

        if (Projects.current) {

            Projects.updateCurrent({
                storySource: source
            });

        }

    },

    getSource() {

        return this.source;

    },

    setText(text) {

        this.text = (text || "").trim();

        if (Projects.current) {

            Projects.updateCurrent({
                storyText: this.text
            });

        }

    },

    append(text) {

        this.text += "\n" + text;

    },

    getText() {

        return this.text;

    },

    clear() {

        this.text = "";
        this.source = "manual";
        this.audio = null;

    },

    hasStory() {

        return this.text.trim().length > 0;

    },

    setAudio(audio) {

        this.audio = audio;

    },

    getAudio() {

        return this.audio;

    },

    /* ==========================================
       PERSISTÊNCIA
    ========================================== */

    hydrate(project) {

        this.source = project.storySource || "manual";
        this.text = project.storyText || "";
        this.audio = null;

    },

    async loadFromAudio(audio) {

        if (!audio) return false;

        this.audio = audio;
        this.source = "audio";

        const text = await Transcription.process(audio);

        this.text = text || "";

        return true;

    },

    loadFromManual(text) {

        this.source = "manual";
        this.text = (text || "").trim();

        return true;

    }

};
