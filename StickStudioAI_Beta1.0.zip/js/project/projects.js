/* =====================================================
   Stick Studio AI
   projects.js
   Gerenciamento de Projetos
===================================================== */

const Projects = {

    list: [],

    current: null,

    async load() {

        return new Promise((resolve) => {

            const store = Database.transaction("projects");
            const request = store.getAll();

            request.onsuccess = async () => {

                this.list = request.result || [];
                this.render();
                await this.restoreLastProject();
                resolve();

            };

        });

    },

    async create(name) {

        if (!name) {

            name = prompt("Nome do projeto:");

        }

        if (!name) return;

        const project = {
            name: name,
            created: new Date().toISOString(),
            status: "Novo",
            storySource: "manual",
            storyText: "",
            transcriptionText: ""
        };

        return new Promise((resolve) => {

            const store = Database.transaction(
                "projects",
                "readwrite"
            );

            const request = store.add(project);

            store.transaction.oncomplete = async () => {

                await this.load();

                if (request.result) {

                    await this.open(request.result);

                }

                resolve();

            };

        });

    },

    async open(id) {

        const project = this.list.find(
            p => p.id === id
        );

        if (!project) return;

        this.current = project;

        localStorage.setItem(
            "lastProject",
            id
        );

        /* Hidrata roteiro / transcrição a partir do projeto */

        if (typeof Story !== "undefined") {

            Story.hydrate(project);

        }

        if (typeof Transcription !== "undefined") {

            Transcription.hydrate(project);

        }

        /* Carrega cenas / memórias / prompts salvos deste projeto */

        if (
            typeof Director !== "undefined" &&
            typeof Director.loadForProject === "function"
        ) {

            await Director.loadForProject(project.id);

        }

        /* Recarrega áudios deste projeto */

        if (
            typeof AudioManager !== "undefined" &&
            typeof AudioManager.load === "function"
        ) {

            AudioManager.load();

        }

        this.render();

        if (typeof UI !== "undefined") {

            UI.updateDashboard();

            if (typeof UI.updateStoryUI === "function") {

                UI.updateStoryUI();

            }

            if (typeof UI.refreshCurrentPage === "function") {

                UI.refreshCurrentPage();

            }

            UI.toast("Projeto \"" + project.name + "\" aberto.");

        }

    },

    async restoreLastProject() {

        const id = Number(
            localStorage.getItem("lastProject")
        );

        if (!id) return;

        await this.open(id);

    },

    update(id, changes) {

        return new Promise((resolve) => {

            const project = this.list.find(
                p => p.id === id
            );

            if (!project) {

                resolve(false);
                return;

            }

            Object.assign(project, changes);

            const store = Database.transaction(
                "projects",
                "readwrite"
            );

            store.put(project);

            store.transaction.oncomplete = () => {

                resolve(true);

            };

            store.transaction.onerror = () => {

                resolve(false);

            };

        });

    },

    updateCurrent(changes) {

        if (!this.current) return Promise.resolve(false);

        return this.update(this.current.id, changes);

    },

    rename(id) {

        const project = this.list.find(
            p => p.id === id
        );

        if (!project) return;

        const newName = prompt(
            "Novo nome:",
            project.name
        );

        if (!newName) return;

        project.name = newName;

        const store = Database.transaction(
            "projects",
            "readwrite"
        );

        store.put(project);

        store.transaction.oncomplete = () => {

            this.load();

        };

    },

    remove(id) {

        const project = this.list.find(
            p => p.id === id
        );

        if (!project) return;

        if (
            !confirm(
                `Excluir "${project.name}"? Isso apaga também
áudios, cenas, personagens e prompts deste projeto.`
            )
        ) return;

        const store = Database.transaction(
            "projects",
            "readwrite"
        );

        store.delete(id);

        store.transaction.oncomplete = async () => {

            /* Remove dados auxiliares do projeto (metadata) */

            if (typeof ProjectData !== "undefined") {

                [
                    "scenes",
                    "characters",
                    "locations",
                    "objects",
                    "prompts"
                ].forEach(key => {

                    ProjectData.remove(key, id);

                });

            }

            if (
                this.current &&
                this.current.id === id
            ) {

                this.current = null;

                localStorage.removeItem(
                    "lastProject"
                );

                if (typeof Scenes !== "undefined") Scenes.clear();
                if (typeof Characters !== "undefined") Characters.clear();
                if (typeof Locations !== "undefined") Locations.clear();
                if (typeof Objects !== "undefined") Objects.clear();
                if (typeof Prompts !== "undefined") Prompts.clear();
                if (typeof Timeline !== "undefined") Timeline.clear();
                if (typeof Story !== "undefined") Story.clear();

            }

            await this.load();

            if (typeof UI !== "undefined") {

                UI.updateDashboard();
                UI.toast("Projeto excluído.");

            }

        };

    },

    render() {

        const container = document.getElementById(
            "projectsContainer"
        );

        if (!container) return;

        container.innerHTML = "";

        if (this.list.length === 0) {

            container.innerHTML = `
                <div class="emptyAudio">
                    <strong>Nenhum projeto.</strong>
                    <small>
                        Crie seu primeiro projeto.
                    </small>
                </div>
            `;

            return;

        }

        this.list.forEach(project => {

            const card = document.createElement("div");

            card.className = "projectItem fadeIn";

            if (
                this.current &&
                this.current.id === project.id
            ) {

                card.classList.add("selected");

            }

            card.innerHTML = `

                <h3>${project.name}</h3>

                <small>
                    ${project.status}
                </small>

                <div class="audioButtons mt-20">

                    <button class="audioPlay">
                        Abrir
                    </button>

                    <button class="audioDelete">
                        Excluir
                    </button>

                </div>

            `;

            card.querySelector(".audioPlay")
                .onclick = () => {

                    this.open(project.id);

                };

            card.querySelector(".audioDelete")
                .onclick = (event) => {

                    event.stopPropagation();

                    this.remove(project.id);

                };

            card.ondblclick = () => {

                this.rename(project.id);

            };

            container.appendChild(card);

        });

    }

};
