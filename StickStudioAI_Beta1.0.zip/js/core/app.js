/* =====================================================
   Stick Studio AI
   app.js
   Inicialização da Aplicação
===================================================== */

const App = {

    async init() {

        console.log("Iniciando Stick Studio AI...");

        try {

            /* Banco */

            await Database.init();

            /* Áudios (precisa estar pronto antes de
               abrir o último projeto usado) */

            AudioManager.init();

            /* Interface (liga os botões estáticos) */

            UI.init();

            /* Projetos (abre o último projeto e
               hidrata roteiro / cenas / prompts) */

            await Projects.load();

            /* Navegação */

            if (typeof Navigation !== "undefined") {

                Navigation.init();

            }

            /* Eventos */

            this.bindEvents();

            /* PWA offline */

            this.registerServiceWorker();

            console.log(
                "Stick Studio AI iniciado com sucesso."
            );

        }

        catch (error) {

            console.error(error);

            alert(
                "Erro ao iniciar a aplicação.\n\n" +
                error.name +
                "\n\n" +
                error.message
            );

        }

    },

    bindEvents() {

        [
            "newProject",
            "newProjectPage"
        ].forEach(id => {

            const button = document.getElementById(id);

            if (!button) return;

            button.onclick = () => {

                Projects.create();

            };

        });

    },

    registerServiceWorker() {

        if (!("serviceWorker" in navigator)) return;

        navigator.serviceWorker
            .register("./service-worker.js")
            .then(() => {

                console.log("Service worker registrado.");

            })
            .catch((error) => {

                console.warn(
                    "Service worker não registrado:",
                    error.message
                );

            });

    }

};

window.addEventListener(

    "load",

    () => {

        App.init();

    }

);
