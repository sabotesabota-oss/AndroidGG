/* =====================================================
   Stick Studio AI
   project-data.js
   Persistência de dados do Diretor (por projeto)
   Usa o object store "metadata" (chave livre) para
   guardar listas (cenas, personagens, cenários,
   objetos, prompts, timeline) sem precisar remapear
   os IDs internos de cada módulo.
===================================================== */

const ProjectData = {

    key(name, projectId) {

        return name + ":" + projectId;

    },

    set(name, projectId, value) {

        return new Promise((resolve, reject) => {

            const store = Database.transaction(
                "metadata",
                "readwrite"
            );

            store.put({
                key: this.key(name, projectId),
                value: value,
                updated: new Date().toISOString()
            });

            store.transaction.oncomplete = () => {
                resolve(true);
            };

            store.transaction.onerror = (event) => {
                console.error(event.target.error);
                reject(event.target.error);
            };

        });

    },

    get(name, projectId) {

        return new Promise((resolve) => {

            const store = Database.transaction(
                "metadata"
            );

            const request = store.get(
                this.key(name, projectId)
            );

            request.onsuccess = () => {
                resolve(
                    request.result
                    ? request.result.value
                    : null
                );
            };

            request.onerror = () => {
                resolve(null);
            };

        });

    },

    remove(name, projectId) {

        return new Promise((resolve) => {

            const store = Database.transaction(
                "metadata",
                "readwrite"
            );

            store.delete(
                this.key(name, projectId)
            );

            store.transaction.oncomplete = () => {
                resolve(true);
            };

        });

    }

};
