/* =====================================================
   Stick Studio AI
   database.js
===================================================== */

const Database = {

    DB_NAME: "StickStudioAI",

    DB_VERSION: 3,

    db: null,

    init() {

        return new Promise((resolve, reject) => {

            const request = indexedDB.open(
                this.DB_NAME,
                this.DB_VERSION
            );

            request.onupgradeneeded = (event) => {

                const db = event.target.result;

                if (typeof DatabaseUpgrade !== "undefined") {

                    DatabaseUpgrade.upgrade(db);

                }

            };

            request.onsuccess = (event) => {

                this.db = event.target.result;

                console.log("Banco iniciado.");

                resolve();

            };

            request.onerror = (event) => {

                console.error(event.target.error);

                reject(event.target.error);

            };

        });

    },

    transaction(store, mode = "readonly") {

        return this.db
            .transaction(store, mode)
            .objectStore(store);

    }

};