/* =====================================================
   Stick Studio AI
   database-upgrade.js
   Atualizações do Banco de Dados
===================================================== */

const DatabaseUpgrade = {

    upgrade(db) {

        this.createProjects(db);
        this.createAudios(db);
        this.createSettings(db);
        this.createMetadata(db);

        this.createTranscriptions(db);
        this.createScenes(db);
        this.createCharacters(db);
        this.createLocations(db);
        this.createObjects(db);
        this.createPrompts(db);
        this.createImages(db);
        this.createQueue(db);

    },

    createProjects(db){

        if(db.objectStoreNames.contains("projects")) return;

        db.createObjectStore(
            "projects",
            {
                keyPath:"id",
                autoIncrement:true
            }
        );

    },

    createAudios(db){

        if(db.objectStoreNames.contains("audios")) return;

        const store = db.createObjectStore(
            "audios",
            {
                keyPath:"id",
                autoIncrement:true
            }
        );

        store.createIndex(
            "projectId",
            "projectId",
            {
                unique:false
            }
        );

    },

    createSettings(db){

        if(db.objectStoreNames.contains("settings")) return;

        db.createObjectStore(
            "settings",
            {
                keyPath:"id",
                autoIncrement:true
            }
        );

    },

    createMetadata(db){

        if(db.objectStoreNames.contains("metadata")) return;

        db.createObjectStore(
            "metadata",
            {
                keyPath:"key"
            }
        );

    },

    createTranscriptions(db){

        this.createSimpleStore(
            db,
            "transcriptions"
        );

    },

    createScenes(db){

        this.createSimpleStore(
            db,
            "scenes"
        );

    },

    createCharacters(db){

        this.createSimpleStore(
            db,
            "characters"
        );

    },

    createLocations(db){

        this.createSimpleStore(
            db,
            "locations"
        );

    },

    createObjects(db){

        this.createSimpleStore(
            db,
            "objects"
        );

    },

    createPrompts(db){

        this.createSimpleStore(
            db,
            "prompts"
        );

    },

    createImages(db){

        this.createSimpleStore(
            db,
            "images"
        );

    },

    createQueue(db){

        this.createSimpleStore(
            db,
            "queue"
        );

    },

    createSimpleStore(db,name){

        if(db.objectStoreNames.contains(name)) return;

        const store = db.createObjectStore(
            name,
            {
                keyPath:"id",
                autoIncrement:true
            }
        );

        store.createIndex(
            "projectId",
            "projectId",
            {
                unique:false
            }
        );

    }

};