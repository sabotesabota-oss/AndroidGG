/* =====================================================
   Stick Studio AI
   ui.js
   Interface do Usuário
===================================================== */

const UI = {

    init() {

        this.bindMenu();
        this.bindStory();
        this.bindTranscriptionManual();
        this.bindDirector();
        this.bindCharactersPage();
        this.bindLocationsPage();
        this.bindObjectsPage();
        this.bindPromptsPage();
        this.bindTimelinePage();
        this.bindEditorPage();
        this.bindSettingsPage();
        this.bindModal();

        this.updateStoryUI();
        this.renderAll();

    },

    /* ==========================================
       MENU LATERAL
    ========================================== */

    bindMenu() {

        const menuButton =
            document.getElementById("menuButton");

        const drawer =
            document.getElementById("drawer");

        const overlay =
            document.getElementById("overlay");

        if (menuButton) {

            menuButton.onclick = () => {

                drawer.classList.toggle("open");
                overlay.classList.toggle("show");

            };

        }

        if (overlay) {

            overlay.onclick = () => {

                drawer.classList.remove("open");
                overlay.classList.remove("show");

            };

        }

    },

    /* ==========================================
       STORY
    ========================================== */

    bindStory() {

        const textarea =
            document.getElementById("storyText");

        const save =
            document.getElementById("saveStory");

        const radios =
            document.querySelectorAll(
                "input[name='storySource']"
            );

        radios.forEach(radio => {

            radio.onchange = () => {

                Story.setSource(radio.value);
                this.updateStoryUI();

            };

        });

        if (textarea) {

            textarea.value = Story.getText();

        }

        if (save) {

            save.onclick = () => {

                Story.setText(textarea.value);
                this.toast("Roteiro salvo.");

            };

        }

    },

    updateStoryUI() {

        const textarea =
            document.getElementById("storyText");

        const manualBox =
            document.getElementById(
                "transcriptionManualBox"
            );

        const radios =
            document.querySelectorAll(
                "input[name='storySource']"
            );

        radios.forEach(radio => {

            radio.checked =
                radio.value === Story.getSource();

        });

        if (!textarea) return;

        if (Story.getSource() === "manual") {

            textarea.disabled = false;
            textarea.style.display = "block";
            textarea.value = Story.getText();

            if (manualBox) {

                manualBox.style.display = "none";

            }

        }

        else {

            textarea.disabled = true;
            textarea.style.display = "none";

            if (manualBox) {

                manualBox.style.display = "block";

                const manualText =
                    document.getElementById(
                        "transcriptionManualText"
                    );

                if (
                    manualText &&
                    document.activeElement !== manualText
                ) {

                    manualText.value =
                        Transcription.getText();

                }

            }

        }

    },

    /* ==========================================
       TRANSCRIÇÃO MANUAL
    ========================================== */

    bindTranscriptionManual() {

        const saveBtn =
            document.getElementById(
                "saveManualTranscription"
            );

        const simulateBtn =
            document.getElementById(
                "simulateTranscription"
            );

        const textarea =
            document.getElementById(
                "transcriptionManualText"
            );

        if (saveBtn) {

            saveBtn.onclick = () => {

                if (!Projects.current) {

                    alert("Abra um projeto primeiro.");
                    return;

                }

                Transcription.setManual(
                    textarea ? textarea.value : ""
                );

                this.toast("Transcrição salva.");
                this.renderAll();

            };

        }

        if (simulateBtn) {

            simulateBtn.onclick = async () => {

                if (!Projects.current) {

                    alert("Abra um projeto primeiro.");
                    return;

                }

                const audio = AudioManager.getMainAudio();

                if (!audio) {

                    alert("Defina um áudio principal na tela Áudios.");
                    return;

                }

                this.showLoading("Transcrevendo (simulado)...");

                await Transcription.process(audio);

                this.hideLoading();

                if (textarea) {

                    textarea.value = Transcription.getText();

                }

                this.toast("Transcrição simulada gerada.");
                this.renderAll();

            };

        }

    },

    /* ==========================================
       DIRETOR IA
    ========================================== */

    bindDirector() {

        const button =
            document.getElementById("analyzeProject");

        if (button) {

            button.onclick = async () => {

                if (!Projects.current) {

                    alert("Abra um projeto.");
                    return;

                }

                if (Story.getSource() === "manual") {

                    if (!Story.hasStory()) {

                        alert("Escreva um roteiro.");
                        return;

                    }

                }

                else {

                    if (
                        !Transcription.getText() &&
                        !AudioManager.getMainAudio()
                    ) {

                        alert(
                            "Defina um áudio principal ou " +
                            "cole uma transcrição."
                        );
                        return;

                    }

                }

                this.showLoading("Analisando projeto...");

                await Director.start(Projects.current.id);

                this.hideLoading();

            };

        }

        const regenerate =
            document.getElementById("regeneratePrompts");

        if (regenerate) {

            regenerate.onclick = () => {

                Director.refreshPrompts();

            };

        }

    },

    renderDirector() {

        this.renderAll();

    },

    /* ==========================================
       RENDERIZAÇÃO GERAL
    ========================================== */

    async renderAll() {

        this.renderTranscription();
        this.renderTimeline();
        this.renderTimelinePage();
        this.renderCharacters();
        this.renderLocations();
        this.renderObjects();
        this.renderPrompts();

        if (
            typeof Storyboard !== "undefined" &&
            typeof Storyboard.render === "function"
        ) {

            await Storyboard.render();

        }

        await this.updateDashboard();

    },

    refreshCurrentPage() {

        this.renderAll();

    },

    /* ==========================================
       TRANSCRIÇÃO
    ========================================== */

    renderTranscription() {

        const el = document.getElementById(
            "transcriptionView"
        );

        if (!el) return;

        let text = "";

        if (Story.getSource() === "manual") {

            text = Story.getText();

        }

        else if (
            typeof Transcription !== "undefined"
        ) {

            text = Transcription.getText();

        }

        el.textContent = text || "Nenhum conteúdo.";

    },

    /* ==========================================
       TIMELINE (visão compacta no Diretor)
    ========================================== */

    renderTimeline() {

        const el = document.getElementById(
            "timelineView"
        );

        if (!el) return;

        el.innerHTML = "";

        if (
            typeof Timeline === "undefined" ||
            typeof Timeline.getAll !== "function"
        ) {

            el.innerHTML = "Timeline indisponível.";
            return;

        }

        const scenes = Timeline.getAll();

        if (!scenes.length) {

            el.innerHTML = "Nenhuma timeline.";
            return;

        }

        scenes.forEach(scene => {

            el.innerHTML += `
<div class="timelineItem">
    <div style="width:100%;">
        <strong>${this.escape(scene.title)}</strong>
        <br>
        ${scene.start}s → ${scene.end}s
        <div class="timelineBar">
            <div class="timelineFill" style="width:${Math.min(scene.duration * 8, 100)}%"></div>
        </div>
    </div>
</div>`;

        });

    },

    /* ==========================================
       TIMELINE (página completa, com edição)
    ========================================== */

    renderTimelinePage() {

        const el = document.getElementById(
            "timelineFull"
        );

        if (!el) return;

        el.innerHTML = "";

        if (
            typeof Timeline === "undefined" ||
            !Timeline.getAll().length
        ) {

            el.innerHTML = "Nenhuma cena criada.";
            return;

        }

        const scenes = Timeline.getAll();

        const total = document.createElement("div");

        total.className = "timelineTotal";

        total.textContent =
            "Duração total: " +
            Utils.formatTime(Timeline.totalDuration()) +
            " (" + scenes.length + " cena(s))";

        el.appendChild(total);

        scenes.forEach((scene, index) => {

            const card = document.createElement("div");

            card.className = "sceneCard fadeIn";

            card.innerHTML = `
                <div class="sceneCardTop">
                    <strong>${index + 1}. ${this.escape(scene.title)}</strong>
                    <span class="sceneCardTime">${scene.start}s → ${scene.end}s</span>
                </div>
                <p class="sceneCardText">${this.escape((scene.scene.text || "").slice(0, 140))}${(scene.scene.text || "").length > 140 ? "…" : ""}</p>
                <div class="sceneCardControls">
                    <label>Duração (s)
                        <input type="number" min="1" class="sceneDurationInput" value="${scene.duration}">
                    </label>
                    <div class="sceneCardButtons">
                        <button class="sceneMoveUp">⬆</button>
                        <button class="sceneMoveDown">⬇</button>
                        <button class="sceneEdit">✏ Editar</button>
                    </div>
                </div>
            `;

            card.querySelector(".sceneDurationInput")
                .onchange = (event) => {

                    const value = Number(event.target.value);

                    if (!value || value <= 0) return;

                    Timeline.setDuration(scene.id, value);

                    if (Projects.current) {

                        Scenes.save(Projects.current.id);

                    }

                    this.renderAll();

                };

            card.querySelector(".sceneMoveUp")
                .onclick = async () => {

                    if (Scenes.move(scene.id, -1)) {

                        Timeline.build();

                        if (Projects.current) {

                            await Scenes.save(Projects.current.id);

                        }

                        this.renderAll();

                    }

                };

            card.querySelector(".sceneMoveDown")
                .onclick = async () => {

                    if (Scenes.move(scene.id, 1)) {

                        Timeline.build();

                        if (Projects.current) {

                            await Scenes.save(Projects.current.id);

                        }

                        this.renderAll();

                    }

                };

            card.querySelector(".sceneEdit")
                .onclick = () => {

                    this.editScene(scene.id);

                };

            el.appendChild(card);

        });

    },

    bindTimelinePage() {

        const newScene =
            document.getElementById("newScenePage");

        if (newScene) {

            newScene.onclick = () => {

                if (!Projects.current) {

                    alert("Abra um projeto primeiro.");
                    return;

                }

                this.editScene(null);

            };

        }

    },

    editScene(id) {

        const existing = id ? Scenes.get(id) : null;

        const nextNumber = Scenes.getAll().length + 1;

        this.openForm(

            existing ? "Editar Cena" : "Nova Cena",

            [
                {
                    key: "title",
                    label: "Título",
                    value: existing
                        ? existing.title
                        : "Cena " + nextNumber
                },
                {
                    key: "text",
                    label: "Descrição da cena",
                    type: "textarea",
                    value: existing ? existing.text : ""
                }
            ],

            async (values) => {

                if (existing) {

                    Scenes.update(id, {
                        title: values.title,
                        text: values.text
                    });

                }

                else {

                    Scenes.add(values.title, values.text);

                }

                Timeline.build();

                if (Projects.current) {

                    await Scenes.save(Projects.current.id);

                }

                this.renderAll();
                this.toast("Cena salva.");

            },

            existing
                ? async () => {

                    Scenes.remove(id);
                    Timeline.build();

                    if (Projects.current) {

                        await Scenes.save(Projects.current.id);

                    }

                    this.renderAll();
                    this.toast("Cena removida.");

                }
                : null

        );

    },

    /* ==========================================
       PERSONAGENS
    ========================================== */

    renderCharacters() {

        this.renderCharactersView();
        this.renderCharactersList();

    },

    renderCharactersView() {

        const el = document.getElementById(
            "charactersView"
        );

        if (!el) return;

        el.innerHTML = "";

        if (
            typeof Characters === "undefined" ||
            !Characters.getAll().length
        ) {

            el.innerHTML = "Nenhum personagem.";
            return;

        }

        Characters.getAll().forEach(item => {

            el.innerHTML += `<div class="memoryItem">👤 ${this.escape(item.name)}</div>`;

        });

    },

    renderCharactersList() {

        const el = document.getElementById(
            "charactersList"
        );

        if (!el) return;

        this.renderEntityList(
            el,
            Characters.getAll(),
            "Nenhum personagem.",
            "👤",
            (id) => this.editCharacter(id)
        );

    },

    bindCharactersPage() {

        const button = document.getElementById(
            "newCharacterPage"
        );

        if (button) {

            button.onclick = () => {

                if (!Projects.current) {

                    alert("Abra um projeto primeiro.");
                    return;

                }

                this.editCharacter(null);

            };

        }

    },

    editCharacter(id) {

        const existing = id ? Characters.get(id) : null;

        const appearance =
            existing ? (existing.appearance || {}) : {};

        this.openForm(

            existing ? "Editar Personagem" : "Novo Personagem",

            [
                { key: "name", label: "Nome", value: existing ? existing.name : "" },
                { key: "description", label: "Descrição geral", type: "textarea", value: existing ? existing.description : "" },
                { key: "age", label: "Idade", value: existing ? existing.age : "" },
                { key: "gender", label: "Gênero", value: existing ? existing.gender : "" },
                { key: "hair", label: "Cabelo", value: appearance.hair || "" },
                { key: "eyes", label: "Olhos", value: appearance.eyes || "" },
                { key: "clothes", label: "Roupas", value: appearance.clothes || "" },
                { key: "colors", label: "Cores predominantes", value: appearance.colors || "" }
            ],

            async (values) => {

                if (!values.name || !values.name.trim()) {

                    this.toast("Informe um nome.");
                    return;

                }

                if (existing) {

                    Characters.update(id, values);

                }

                else {

                    Characters.add(values);

                }

                if (Projects.current) {

                    await Characters.save(Projects.current.id);

                }

                this.renderAll();
                this.toast("Personagem salvo.");

            },

            existing
                ? async () => {

                    Characters.remove(id);

                    if (Projects.current) {

                        await Characters.save(Projects.current.id);

                    }

                    this.renderAll();
                    this.toast("Personagem removido.");

                }
                : null

        );

    },

    /* ==========================================
       CENÁRIOS
    ========================================== */

    renderLocations() {

        this.renderLocationsView();
        this.renderLocationsList();

    },

    renderLocationsView() {

        const el = document.getElementById(
            "locationsView"
        );

        if (!el) return;

        el.innerHTML = "";

        if (
            typeof Locations === "undefined" ||
            !Locations.getAll().length
        ) {

            el.innerHTML = "Nenhum cenário.";
            return;

        }

        Locations.getAll().forEach(item => {

            el.innerHTML += `<div class="memoryItem">🌍 ${this.escape(item.name)}</div>`;

        });

    },

    renderLocationsList() {

        const el = document.getElementById(
            "locationsList"
        );

        if (!el) return;

        this.renderEntityList(
            el,
            Locations.getAll(),
            "Nenhum cenário.",
            "🌍",
            (id) => this.editLocation(id)
        );

    },

    bindLocationsPage() {

        const button = document.getElementById(
            "newLocationPage"
        );

        if (button) {

            button.onclick = () => {

                if (!Projects.current) {

                    alert("Abra um projeto primeiro.");
                    return;

                }

                this.editLocation(null);

            };

        }

    },

    editLocation(id) {

        const existing = id ? Locations.get(id) : null;

        this.openForm(

            existing ? "Editar Cenário" : "Novo Cenário",

            [
                { key: "name", label: "Nome", value: existing ? existing.name : "" },
                { key: "description", label: "Descrição", type: "textarea", value: existing ? existing.description : "" },
                { key: "style", label: "Estilo visual", value: existing ? existing.style : "" },
                { key: "lighting", label: "Iluminação", value: existing ? existing.lighting : "" },
                { key: "weather", label: "Clima/hora do dia", value: existing ? existing.weather : "" }
            ],

            async (values) => {

                if (!values.name || !values.name.trim()) {

                    this.toast("Informe um nome.");
                    return;

                }

                if (existing) {

                    Locations.update(id, values);

                }

                else {

                    Locations.add(values);

                }

                if (Projects.current) {

                    await Locations.save(Projects.current.id);

                }

                this.renderAll();
                this.toast("Cenário salvo.");

            },

            existing
                ? async () => {

                    Locations.remove(id);

                    if (Projects.current) {

                        await Locations.save(Projects.current.id);

                    }

                    this.renderAll();
                    this.toast("Cenário removido.");

                }
                : null

        );

    },

    /* ==========================================
       OBJETOS
    ========================================== */

    renderObjects() {

        this.renderObjectsView();
        this.renderObjectsList();

    },

    renderObjectsView() {

        const el = document.getElementById(
            "objectsView"
        );

        if (!el) return;

        el.innerHTML = "";

        if (
            typeof Objects === "undefined" ||
            !Objects.getAll().length
        ) {

            el.innerHTML = "Nenhum objeto.";
            return;

        }

        Objects.getAll().forEach(item => {

            el.innerHTML += `<div class="memoryItem">📦 ${this.escape(item.name)}</div>`;

        });

    },

    renderObjectsList() {

        const el = document.getElementById(
            "objectsList"
        );

        if (!el) return;

        this.renderEntityList(
            el,
            Objects.getAll(),
            "Nenhum objeto.",
            "📦",
            (id) => this.editObject(id)
        );

    },

    bindObjectsPage() {

        const button = document.getElementById(
            "newObjectPage"
        );

        if (button) {

            button.onclick = () => {

                if (!Projects.current) {

                    alert("Abra um projeto primeiro.");
                    return;

                }

                this.editObject(null);

            };

        }

    },

    editObject(id) {

        const existing = id ? Objects.get(id) : null;

        this.openForm(

            existing ? "Editar Objeto" : "Novo Objeto",

            [
                { key: "name", label: "Nome", value: existing ? existing.name : "" },
                { key: "description", label: "Descrição", type: "textarea", value: existing ? existing.description : "" },
                { key: "category", label: "Categoria", value: existing ? existing.category : "" },
                { key: "color", label: "Cor", value: existing ? existing.color : "" },
                { key: "style", label: "Estilo visual", value: existing ? existing.style : "" }
            ],

            async (values) => {

                if (!values.name || !values.name.trim()) {

                    this.toast("Informe um nome.");
                    return;

                }

                if (existing) {

                    Objects.update(id, values);

                }

                else {

                    Objects.add(values);

                }

                if (Projects.current) {

                    await Objects.save(Projects.current.id);

                }

                this.renderAll();
                this.toast("Objeto salvo.");

            },

            existing
                ? async () => {

                    Objects.remove(id);

                    if (Projects.current) {

                        await Objects.save(Projects.current.id);

                    }

                    this.renderAll();
                    this.toast("Objeto removido.");

                }
                : null

        );

    },

    /* ==========================================
       LISTA GENÉRICA (personagens/cenários/objetos)
    ========================================== */

    renderEntityList(el, list, emptyMessage, icon, onEdit) {

        el.innerHTML = "";

        if (!list.length) {

            el.innerHTML = `
                <div class="emptyAudio">
                    <strong>${emptyMessage}</strong>
                    <small>Toque em Adicionar para criar um novo.</small>
                </div>
            `;

            return;

        }

        list.forEach(item => {

            const card = document.createElement("div");

            card.className = "entityCard fadeIn";

            const sceneCount =
                (item.scenes && item.scenes.length) || 0;

            card.innerHTML = `
                <div class="entityCardTop">
                    <strong>${icon} ${this.escape(item.name)}</strong>
                    <span class="entityCardScenes">${sceneCount} cena(s)</span>
                </div>
                <p class="entityCardDesc">${this.escape(item.description || "Sem descrição ainda — toque em Editar para detalhar.")}</p>
                <div class="entityCardButtons">
                    <button class="entityEdit">✏ Editar</button>
                </div>
            `;

            card.querySelector(".entityEdit").onclick = () => {

                onEdit(item.id);

            };

            el.appendChild(card);

        });

    },

    /* ==========================================
       PROMPTS
    ========================================== */

    renderPrompts() {

        this.renderPromptsView();
        this.renderPromptsList();

    },

    renderPromptsView() {

        const el = document.getElementById(
            "promptsView"
        );

        if (!el) return;

        el.innerHTML = "";

        if (
            typeof Prompts === "undefined" ||
            !Prompts.getAll().length
        ) {

            el.innerHTML = "Nenhum prompt.";
            return;

        }

        Prompts.getAll().forEach(item => {

            el.innerHTML += `<div class="promptCard">${this.escape(item.prompt)}</div>`;

        });

    },

    renderPromptsList() {

        const el = document.getElementById(
            "promptsList"
        );

        if (!el) return;

        el.innerHTML = "";

        const list = Prompts.getAll();

        if (!list.length) {

            el.innerHTML = `
                <div class="emptyAudio">
                    <strong>Nenhum prompt gerado.</strong>
                    <small>Analise o projeto na tela Diretor IA.</small>
                </div>
            `;

            return;

        }

        list.forEach((item, index) => {

            const card = document.createElement("div");

            card.className = "promptCardFull fadeIn";

            if (item.used) card.classList.add("used");

            card.innerHTML = `
                <div class="promptCardHeader">
                    <strong>Cena ${index + 1}${item.edited ? " ✏" : ""}</strong>
                    <span>${item.used ? "✅ Gerado" : "⏳ Pendente"}</span>
                </div>
                <pre class="promptCardText">${this.escape(item.prompt)}</pre>
                <div class="promptCardButtons">
                    <button class="promptCopy">📋 Copiar</button>
                    <button class="promptToggle">${item.used ? "Desmarcar" : "Marcar gerado"}</button>
                    <button class="promptEditBtn">✏ Editar</button>
                </div>
            `;

            card.querySelector(".promptCopy").onclick = () => {

                this.copyPrompt(item.id);

            };

            card.querySelector(".promptToggle").onclick = async () => {

                Prompts.toggleUsed(item.id);

                if (Projects.current) {

                    await Prompts.save(Projects.current.id);

                }

                this.renderAll();

            };

            card.querySelector(".promptEditBtn").onclick = () => {

                this.editPrompt(item.id);

            };

            el.appendChild(card);

        });

    },

    bindPromptsPage() {

        const button = document.getElementById(
            "regeneratePromptsPage"
        );

        if (button) {

            button.onclick = () => {

                Director.refreshPrompts();

            };

        }

    },

    editPrompt(id) {

        const existing = Prompts.get(id);

        if (!existing) return;

        this.openForm(

            "Editar Prompt",

            [
                {
                    key: "prompt",
                    label: "Texto do prompt",
                    type: "textarea",
                    value: existing.prompt
                }
            ],

            async (values) => {

                Prompts.update(id, values.prompt);

                if (Projects.current) {

                    await Prompts.save(Projects.current.id);

                }

                this.renderAll();
                this.toast("Prompt atualizado.");

            },

            async () => {

                Prompts.remove(id);

                if (Projects.current) {

                    await Prompts.save(Projects.current.id);

                }

                this.renderAll();
                this.toast("Prompt removido.");

            }

        );

    },

    async copyPrompt(id) {

        const item = Prompts.get(id);

        if (!item) return;

        try {

            await navigator.clipboard.writeText(item.prompt);
            this.toast("Prompt copiado.");

        }

        catch (error) {

            this.toast("Não foi possível copiar automaticamente.");

        }

    },

    /* ==========================================
       DASHBOARD
    ========================================== */

    async updateDashboard() {

        const currentProject =
            document.getElementById("currentProject");

        const projectStatus =
            document.getElementById("projectStatus");

        const audioCount =
            document.getElementById("audioCount");

        const sceneCount =
            document.getElementById("sceneCount");

        const promptCount =
            document.getElementById("promptCount");

        const characterCount =
            document.getElementById("characterCount");

        const imageCount =
            document.getElementById("imageCount");

        if (currentProject) {

            currentProject.textContent =
                Projects.current
                    ? Projects.current.name
                    : "Nenhum projeto";

        }

        if (projectStatus) {

            projectStatus.textContent =
                Projects.current
                    ? "Status: " + Projects.current.status
                    : "Status: aguardando projeto.";

        }

        if (audioCount) {

            audioCount.textContent =
                typeof AudioManager !== "undefined"
                    ? AudioManager.count()
                    : 0;

        }

        if (
            sceneCount &&
            typeof Timeline !== "undefined"
        ) {

            sceneCount.textContent =
                Timeline.getAll().length;

        }

        if (
            promptCount &&
            typeof Prompts !== "undefined"
        ) {

            promptCount.textContent =
                Prompts.getAll().length;

        }

        if (
            characterCount &&
            typeof Characters !== "undefined"
        ) {

            characterCount.textContent =
                Characters.getAll().length;

        }

        if (
            imageCount &&
            Projects.current &&
            typeof Storyboard !== "undefined" &&
            typeof Storyboard.countImages === "function"
        ) {

            imageCount.textContent =
                await Storyboard.countImages(
                    Projects.current.id
                );

        }

        else if (imageCount) {

            imageCount.textContent = 0;

        }

    },

    /* ==========================================
       STORYBOARD / EDITOR
    ========================================== */

    bindEditorPage() {

        const exportPrompts =
            document.getElementById("exportPromptsBtn");

        const exportCapcut =
            document.getElementById("exportCapcutBtn");

        if (exportPrompts) {

            exportPrompts.onclick = () => {

                if (typeof StudioExport === "undefined") return;

                StudioExport.exportPrompts();

            };

        }

        if (exportCapcut) {

            exportCapcut.onclick = () => {

                if (typeof StudioExport === "undefined") return;

                StudioExport.exportCapcutZip();

            };

        }

    },

    /* ==========================================
       CONFIGURAÇÕES
    ========================================== */

    bindSettingsPage() {

        const exportBackup =
            document.getElementById("exportBackupBtn");

        const importBackup =
            document.getElementById("importBackupBtn");

        const importInput =
            document.getElementById("importBackupInput");

        const wipeBtn =
            document.getElementById("wipeDataBtn");

        if (exportBackup) {

            exportBackup.onclick = () => {

                if (
                    typeof StudioExport === "undefined"
                ) return;

                StudioExport.exportBackup();

            };

        }

        if (importBackup && importInput) {

            importBackup.onclick = () => {

                importInput.click();

            };

            importInput.onchange = async (event) => {

                const file = event.target.files[0];

                importInput.value = "";

                if (!file) return;

                if (
                    typeof StudioExport === "undefined"
                ) return;

                await StudioExport.importBackup(file);

            };

        }

        if (wipeBtn) {

            wipeBtn.onclick = () => {

                if (
                    typeof StudioExport === "undefined"
                ) return;

                StudioExport.wipeAllData();

            };

        }

    },

    /* ==========================================
       MODAL GENÉRICO
    ========================================== */

    bindModal() {

        const overlay =
            document.getElementById("modalOverlay");

        if (overlay) {

            overlay.addEventListener("click", (event) => {

                if (event.target === overlay) {

                    this.closeModal();

                }

            });

        }

    },

    openForm(title, fields, onSave, onDelete) {

        const box = document.getElementById("modalBox");
        const overlay = document.getElementById("modalOverlay");

        if (!box || !overlay) return;

        let html = `<h3>${this.escape(title)}</h3><div class="modalFields">`;

        fields.forEach(field => {

            const value = this.escapeAttr(field.value || "");

            if (field.type === "textarea") {

                html += `
                    <label>${this.escape(field.label)}
                        <textarea data-key="${field.key}" rows="4">${this.escape(field.value || "")}</textarea>
                    </label>
                `;

            }

            else {

                html += `
                    <label>${this.escape(field.label)}
                        <input data-key="${field.key}" type="text" value="${value}">
                    </label>
                `;

            }

        });

        html += `</div><div class="modalButtons">`;

        if (onDelete) {

            html += `<button id="modalDeleteBtn" class="btnDanger">Excluir</button>`;

        }

        html += `
            <button id="modalCancelBtn" class="btnSecondary">Cancelar</button>
            <button id="modalSaveBtn">Salvar</button>
        </div>`;

        box.innerHTML = html;

        overlay.classList.add("show");

        document.getElementById("modalCancelBtn").onclick = () => {

            this.closeModal();

        };

        document.getElementById("modalSaveBtn").onclick = () => {

            const values = {};

            box.querySelectorAll("[data-key]").forEach(el => {

                values[el.dataset.key] = el.value;

            });

            this.closeModal();
            onSave(values);

        };

        if (onDelete) {

            document.getElementById("modalDeleteBtn").onclick = () => {

                if (!confirm("Tem certeza que deseja excluir?")) return;

                this.closeModal();
                onDelete();

            };

        }

    },

    closeModal() {

        const overlay =
            document.getElementById("modalOverlay");

        if (overlay) overlay.classList.remove("show");

    },

    /* ==========================================
       UTILIDADES
    ========================================== */

    showLoading(message = "Carregando...") {

        const overlay =
            document.getElementById("loadingOverlay");

        const msg =
            document.getElementById("loadingMessage");

        if (msg) msg.textContent = message;
        if (overlay) overlay.classList.add("show");

    },

    hideLoading() {

        const overlay =
            document.getElementById("loadingOverlay");

        if (overlay) overlay.classList.remove("show");

    },

    toast(message, duration = 2600) {

        const box = document.getElementById("toastBox");

        if (!box) {

            console.log(message);
            return;

        }

        const item = document.createElement("div");

        item.className = "toastItem";
        item.textContent = message;

        box.appendChild(item);

        setTimeout(() => {

            item.classList.add("out");

            setTimeout(() => {

                item.remove();

            }, 300);

        }, duration);

    },

    escape(text) {

        if (text === null || text === undefined) return "";

        return String(text)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;");

    },

    escapeAttr(text) {

        return this.escape(text).replace(/"/g, "&quot;");

    }

};
