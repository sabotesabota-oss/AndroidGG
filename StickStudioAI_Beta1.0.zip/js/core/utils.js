/* =====================================================
   Stick Studio AI
   utils.js
   Funções Utilitárias
===================================================== */

const Utils = {

    formatBytes(bytes) {

        if (bytes === 0) return "0 B";

        const k = 1024;

        const sizes = [

            "B",

            "KB",

            "MB",

            "GB"

        ];

        const i = Math.floor(

            Math.log(bytes) /

            Math.log(k)

        );

        return (

            bytes /

            Math.pow(k, i)

        ).toFixed(2) +

        " " +

        sizes[i];

    },

    formatTime(seconds) {

        if (

            !seconds ||

            isNaN(seconds)

        ) {

            return "00:00";

        }

        const min = Math.floor(

            seconds / 60

        );

        const sec = Math.floor(

            seconds % 60

        );

        return (

            String(min).padStart(2,"0")

            +

            ":"

            +

            String(sec).padStart(2,"0")

        );

    },

    formatDate(date) {

        const d = new Date(date);

        return d.toLocaleDateString(

            "pt-BR",

            {

                day:"2-digit",

                month:"2-digit",

                year:"numeric"

            }

        );

    },

    uuid() {

        return (

            Date.now().toString(36)

            +

            Math.random()

            .toString(36)

            .substring(2,10)

        );

    },

    download(blob,fileName){

        const url = URL.createObjectURL(blob);

        const a = document.createElement("a");

        a.href = url;

        a.download = fileName;

        a.click();

        URL.revokeObjectURL(url);

    },

    clone(object){

        return JSON.parse(

            JSON.stringify(object)

        );

    },

    debounce(callback,delay=300){

        let timer;

        return (...args)=>{

            clearTimeout(timer);

            timer = setTimeout(()=>{

                callback(...args);

            },delay);

        };

    },

    sleep(ms){

        return new Promise(resolve=>{

            setTimeout(resolve,ms);

        });

    },

    capitalize(text){

        if(!text) return "";

        return text.charAt(0).toUpperCase()

        +

        text.slice(1);

    },

    fileExtension(fileName){

        const parts = fileName.split(".");

        return parts.pop().toLowerCase();

    },

    isAudio(file){

        if(!file) return false;

        return file.type.startsWith(

            "audio/"

        );

    }

};