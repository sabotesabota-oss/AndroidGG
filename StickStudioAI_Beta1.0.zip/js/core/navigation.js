/* =====================================================
   Stick Studio AI
   navigation.js
   Controle de Navegação
===================================================== */

const Navigation = {

    /* ==========================================
       CONFIGURAÇÃO
    ========================================== */

    currentPage: "dashboard",

    pages: [

        "dashboard",
        "projects",
        "audio",
        "story",
        "director",
        "timeline",
        "characters",
        "locations",
        "objects",
        "prompts",
        "editor",
        "settings"

    ],

    bottomPages: [

        "dashboard",
        "projects",
        "audio",
        "story",
        "director"

    ],

    /* ==========================================
       INICIALIZAÇÃO
    ========================================== */

    init() {

        console.log("Navigation iniciado.");

        this.bindDrawer();
        this.bindBottomBar();
        this.show("dashboard");

    },

    /* ==========================================
       UTILIDADES
    ========================================== */

    capitalize(text) {

        return text.charAt(0).toUpperCase() +
               text.slice(1);

    },

    getButton(prefix, page) {

        return document.getElementById(

            prefix + this.capitalize(page)

        );

    },

    getSection(page) {

        return document.getElementById(

            page + "Page"

        );

    },

    /* ==========================================
       MENU LATERAL
    ========================================== */

    bindDrawer() {

        this.pages.forEach(page => {

            const button =
                this.getButton("menu", page);

            if (!button) return;

            button.onclick = () => {

                this.show(page);

            };

        });

    },

    /* ==========================================
       BARRA INFERIOR
    ========================================== */

    bindBottomBar() {

        this.bottomPages.forEach(page => {

            const button =
                this.getButton("bottom", page);

            if (!button) return;

            button.onclick = () => {

                this.show(page);

            };

        });

    },

    /* ==========================================
       TROCAR PÁGINA
    ========================================== */

    show(page) {

        if (!this.pages.includes(page)) {

            console.warn("Página inexistente:", page);
            return;

        }

        this.currentPage = page;

        this.pages.forEach(name => {

            const section = this.getSection(name);

            if (!section) return;

            section.style.display =
                name === page ? "block" : "none";

        });

        this.updateActiveButtons();
        this.closeDrawer();
        this.afterPageChange(page);

    },

    /* ==========================================
       EVENTOS APÓS NAVEGAÇÃO
    ========================================== */

    afterPageChange(page) {

        if (typeof UI === "undefined") return;

        if (page === "story") {

            UI.updateStoryUI();

        }

        if (typeof UI.renderAll === "function") {

            UI.renderAll();

        }

    },

    /* ==========================================
       BOTÕES ATIVOS
    ========================================== */

    updateActiveButtons() {

        this.pages.forEach(page => {

            const button = this.getButton("menu", page);

            if (!button) return;

            button.classList.toggle(
                "active",
                page === this.currentPage
            );

        });

        this.bottomPages.forEach(page => {

            const button = this.getButton("bottom", page);

            if (!button) return;

            button.classList.toggle(
                "active",
                page === this.currentPage
            );

        });

    },

    /* ==========================================
       DRAWER
    ========================================== */

    openDrawer() {

        const drawer = document.getElementById("drawer");
        const overlay = document.getElementById("overlay");

        if (drawer) drawer.classList.add("open");
        if (overlay) overlay.classList.add("show");

    },

    closeDrawer() {

        const drawer = document.getElementById("drawer");
        const overlay = document.getElementById("overlay");

        if (drawer) drawer.classList.remove("open");
        if (overlay) overlay.classList.remove("show");

    }

};
