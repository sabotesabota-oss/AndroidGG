/* =====================================================
   Stick Studio AI
   export.js
   Exportação de prompts, storyboard (CapCut) e backups
===================================================== */

const StudioExport = {

    /* ==========================================
       UTILIDADES
    ========================================== */

    slug(text) {

        return (text || "cena")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[^a-zA-Z0-9]+/g, "-")
            .replace(/^-+|-+$/g, "")
            .toLowerCase()
            .slice(0, 40) || "cena";

    },

    extensionFor(type) {

        const map = {
            "image/png": "png",
            "image/jpeg": "jpg",
            "image/jpg": "jpg",
            "image/webp": "webp",
            "image/gif": "gif"
        };

        return map[type] || "png";

    },

    blobToBase64(blob) {

        return new Promise((resolve, reject) => {

            const reader = new FileReader();

            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;

            reader.readAsDataURL(blob);

        });

    },

    base64ToBlob(dataUrl) {

        const parts = dataUrl.split(",");
        const meta = parts[0];
        const base64 = parts[1];
        const mimeMatch = meta.match(/data:(.*);base64/);
        const mime = mimeMatch ? mimeMatch[1] : "image/png";

        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);

        for (let i = 0; i < binary.length; i++) {

            bytes[i] = binary.charCodeAt(i);

        }

        return new Blob([bytes], { type: mime });

    },

    /* ==========================================
       EXPORTAR PROMPTS (.txt)
    ========================================== */

    exportPrompts() {

        if (!Projects.current) {

            UI.toast("Abra um projeto primeiro.");
            return;

        }

        const scenes = Timeline.getAll();

        if (!scenes.length) {

            UI.toast("Nenhuma cena para exportar.");
            return;

        }

        let content =
            "STICK STUDIO AI — Prompts\n" +
            "Projeto: " + Projects.current.name + "\n" +
            "Gerado em: " +
            new Date().toLocaleString("pt-BR") +
            "\n\n" +
            "=".repeat(40) + "\n\n";

        scenes.forEach((scene, index) => {

            const promptItem = Prompts.get(scene.id);

            content +=
                "Cena " + (index + 1) +
                " — " + scene.title +
                " (" + scene.duration + "s)\n\n" +
                (promptItem
                    ? promptItem.prompt
                    : "(sem prompt gerado)") +
                "\n\n" + "-".repeat(40) + "\n\n";

        });

        const blob = new Blob([content], {
            type: "text/plain;charset=utf-8"
        });

        Utils.download(
            blob,
            this.slug(Projects.current.name) + "-prompts.txt"
        );

        UI.toast("Prompts exportados.");

    },

    /* ==========================================
       EXPORTAR PARA CAPCUT (.zip)
    ========================================== */

    async exportCapcutZip() {

        if (!Projects.current) {

            UI.toast("Abra um projeto primeiro.");
            return;

        }

        const scenes = Timeline.getAll();

        if (!scenes.length) {

            UI.toast("Nenhuma cena para exportar.");
            return;

        }

        UI.showLoading("Preparando exportação...");

        try {

            const ordered = await Storyboard.getOrderedImages(
                Projects.current.id
            );

            const zip = new ZipWriter();

            let manifest =
                "STICK STUDIO AI — Storyboard para CapCut\n" +
                "Projeto: " + Projects.current.name + "\n" +
                "Gerado em: " +
                new Date().toLocaleString("pt-BR") + "\n\n" +
                "Ordem | Cena | Duração | Arquivo\n" +
                "-".repeat(50) + "\n";

            let promptsTxt = "";
            let missing = 0;

            for (let index = 0; index < ordered.length; index++) {

                const entry = ordered[index];
                const order = String(index + 1).padStart(3, "0");
                const scene = entry.scene;
                const promptItem = Prompts.get(scene.id);

                let fileName = "(sem imagem)";

                if (entry.image && entry.image.blob) {

                    const ext = this.extensionFor(
                        entry.image.type ||
                        entry.image.blob.type
                    );

                    fileName =
                        order + "_" +
                        this.slug(scene.title) + "." + ext;

                    /* Blob precisa virar ArrayBuffer antes de
                       entrar no zip — o ZipWriter não lê Blob
                       diretamente (leitura é assíncrona). */

                    const arrayBuffer =
                        await entry.image.blob.arrayBuffer();

                    zip.addFile(
                        "imagens/" + fileName,
                        arrayBuffer
                    );

                }

                else {

                    missing++;

                }

                manifest +=
                    order + " | " +
                    scene.title + " | " +
                    scene.duration + "s | " +
                    fileName + "\n";

                promptsTxt +=
                    order + " — " + scene.title + "\n\n" +
                    (promptItem
                        ? promptItem.prompt
                        : "(sem prompt gerado)") +
                    "\n\n" + "-".repeat(40) + "\n\n";

            }

            if (missing) {

                manifest +=
                    "\n⚠ " + missing +
                    " cena(s) sem imagem anexada. " +
                    "Volte ao Storyboard para completar.\n";

            }

            zip.addFile("manifest.txt", manifest);
            zip.addFile("prompts.txt", promptsTxt);

            const blob = zip.generateBlob();

            Utils.download(
                blob,
                this.slug(Projects.current.name) +
                "-capcut.zip"
            );

            UI.hideLoading();

            if (missing) {

                UI.toast(
                    "Exportado com " + missing +
                    " cena(s) sem imagem."
                );

            }

            else {

                UI.toast("Exportado para CapCut com sucesso.");

            }

        }

        catch (error) {

            console.error(error);
            UI.hideLoading();
            UI.toast("Erro ao exportar.");

        }

    },

    /* ==========================================
       BACKUP COMPLETO (.json)
    ========================================== */

    async exportBackup() {

        if (!Projects.current) {

            UI.toast("Abra um projeto primeiro.");
            return;

        }

        UI.showLoading("Gerando backup...");

        try {

            const projectId = Projects.current.id;

            const images = await Storyboard.loadImages(
                projectId
            );

            const imagesEncoded = [];

            for (const image of images) {

                imagesEncoded.push({
                    sceneId: image.sceneId,
                    name: image.name,
                    type: image.type,
                    created: image.created,
                    data: await this.blobToBase64(image.blob)
                });

            }

            const backup = {
                app: "Stick Studio AI",
                version: 2,
                exportedAt: new Date().toISOString(),
                project: Projects.current,
                scenes: Scenes.getAll(),
                characters: Characters.getAll(),
                locations: Locations.getAll(),
                objects: Objects.getAll(),
                prompts: Prompts.getAll(),
                images: imagesEncoded
            };

            const blob = new Blob(
                [JSON.stringify(backup, null, 2)],
                { type: "application/json" }
            );

            Utils.download(
                blob,
                this.slug(Projects.current.name) +
                "-backup.json"
            );

            UI.hideLoading();
            UI.toast("Backup exportado.");

        }

        catch (error) {

            console.error(error);
            UI.hideLoading();
            UI.toast("Erro ao gerar backup.");

        }

    },

    /* ==========================================
       IMPORTAR BACKUP (.json)
    ========================================== */

    async importBackup(file) {

        UI.showLoading("Importando backup...");

        try {

            const text = await file.text();
            const backup = JSON.parse(text);

            if (!backup || !backup.project) {

                throw new Error("Arquivo de backup inválido.");

            }

            const name =
                (backup.project.name || "Projeto importado") +
                " (importado)";

            const newProject = {
                name,
                created: new Date().toISOString(),
                status: "Importado",
                storySource: backup.project.storySource || "manual",
                storyText: backup.project.storyText || "",
                transcriptionText:
                    backup.project.transcriptionText || ""
            };

            const projectStore = Database.transaction(
                "projects",
                "readwrite"
            );

            const request = projectStore.add(newProject);

            await new Promise((resolve, reject) => {

                projectStore.transaction.oncomplete = resolve;
                projectStore.transaction.onerror = reject;

            });

            const newProjectId = request.result;

            await ProjectData.set(
                "scenes", newProjectId, backup.scenes || []
            );

            await ProjectData.set(
                "characters", newProjectId,
                backup.characters || []
            );

            await ProjectData.set(
                "locations", newProjectId,
                backup.locations || []
            );

            await ProjectData.set(
                "objects", newProjectId, backup.objects || []
            );

            await ProjectData.set(
                "prompts", newProjectId, backup.prompts || []
            );

            if (backup.images && backup.images.length) {

                for (const image of backup.images) {

                    const blob = this.base64ToBlob(image.data);

                    const imageStore = Database.transaction(
                        "images",
                        "readwrite"
                    );

                    imageStore.add({
                        projectId: newProjectId,
                        sceneId: image.sceneId,
                        blob,
                        name: image.name,
                        type: image.type,
                        created: image.created ||
                            new Date().toISOString()
                    });

                    await new Promise((resolve) => {

                        imageStore.transaction.oncomplete =
                            resolve;

                        imageStore.transaction.onerror =
                            resolve;

                    });

                }

            }

            await Projects.load();
            await Projects.open(newProjectId);

            UI.hideLoading();
            UI.toast("Backup importado como novo projeto.");

        }

        catch (error) {

            console.error(error);
            UI.hideLoading();
            alert(
                "Não foi possível importar o backup.\n" +
                error.message
            );

        }

    },

    /* ==========================================
       APAGAR TODOS OS DADOS
    ========================================== */

    wipeAllData() {

        if (
            !confirm(
                "Isso vai apagar TODOS os projetos, áudios, " +
                "cenas, personagens e imagens do dispositivo. " +
                "Esta ação não pode ser desfeita.\n\n" +
                "Deseja continuar?"
            )
        ) return;

        if (
            !confirm(
                "Tem certeza mesmo? Considere exportar um " +
                "backup antes de continuar."
            )
        ) return;

        UI.showLoading("Apagando dados...");

        const request = indexedDB.deleteDatabase(
            Database.DB_NAME
        );

        const finish = () => {

            localStorage.removeItem("lastProject");
            localStorage.removeItem("lastAudio");

            window.location.reload();

        };

        request.onsuccess = finish;
        request.onerror = finish;
        request.onblocked = finish;

    }

};
