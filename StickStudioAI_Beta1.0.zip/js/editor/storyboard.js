/* =====================================================
   Stick Studio AI
   storyboard.js
   Anexação de imagens geradas por IA a cada cena
===================================================== */

const Storyboard = {

    images: [],

    /* ==========================================
       CARREGAMENTO
    ========================================== */

    loadImages(projectId) {

        return new Promise((resolve) => {

            if (!projectId) {

                this.images = [];
                resolve(this.images);
                return;

            }

            const store = Database.transaction("images");
            const index = store.index("projectId");
            const request = index.getAll(projectId);

            request.onsuccess = () => {

                this.images = request.result || [];
                resolve(this.images);

            };

            request.onerror = () => {

                this.images = [];
                resolve(this.images);

            };

        });

    },

    getImageForScene(sceneId) {

        const matches = this.images.filter(
            image => image.sceneId === sceneId
        );

        if (!matches.length) return null;

        return matches[matches.length - 1];

    },

    countImages(projectId) {

        return new Promise((resolve) => {

            if (!projectId) {

                resolve(0);
                return;

            }

            const store = Database.transaction("images");
            const index = store.index("projectId");
            const request = index.getAll(projectId);

            request.onsuccess = () => {

                resolve((request.result || []).length);

            };

            request.onerror = () => {

                resolve(0);

            };

        });

    },

    /* ==========================================
       ANEXAR / REMOVER
    ========================================== */

    async attachImage(projectId, sceneId, file) {

        await this.removeImagesForScene(projectId, sceneId);

        return new Promise((resolve) => {

            const store = Database.transaction(
                "images",
                "readwrite"
            );

            store.add({
                projectId,
                sceneId,
                blob: file,
                name: file.name,
                type: file.type,
                created: new Date().toISOString()
            });

            store.transaction.oncomplete = async () => {

                await this.loadImages(projectId);
                resolve(true);

            };

            store.transaction.onerror = () => {

                resolve(false);

            };

        });

    },

    async removeImagesForScene(projectId, sceneId) {

        const existing = this.images.filter(
            image =>
                image.projectId === projectId &&
                image.sceneId === sceneId
        );

        if (!existing.length) return true;

        return new Promise((resolve) => {

            const store = Database.transaction(
                "images",
                "readwrite"
            );

            existing.forEach(image => {

                store.delete(image.id);

            });

            store.transaction.oncomplete = () => {

                resolve(true);

            };

            store.transaction.onerror = () => {

                resolve(false);

            };

        });

    },

    /* ==========================================
       EXPORTAÇÃO
    ========================================== */

    async getOrderedImages(projectId) {

        await this.loadImages(projectId);

        const scenes = Timeline.getAll();

        return scenes.map(scene => ({
            scene,
            image: this.getImageForScene(scene.id)
        }));

    },

    /* ==========================================
       RENDERIZAÇÃO
    ========================================== */

    async render() {

        const el = document.getElementById(
            "storyboardList"
        );

        if (!el) return;

        el.innerHTML = "";

        if (!Projects.current) {

            el.innerHTML =
                "Abra um projeto para ver o storyboard.";
            return;

        }

        await this.loadImages(Projects.current.id);

        const scenes = Timeline.getAll();

        if (!scenes.length) {

            el.innerHTML =
                "Nenhuma cena criada. Analise o projeto " +
                "na tela Diretor IA primeiro.";
            return;

        }

        scenes.forEach((scene, index) => {

            const image = this.getImageForScene(scene.id);
            const promptItem = Prompts.get(scene.id);

            const card = document.createElement("div");

            card.className = "storyboardCard fadeIn";

            const promptPreview = promptItem
                ? UI.escape(
                    promptItem.prompt
                        .replace(/\s+/g, " ")
                        .slice(0, 130)
                ) + "…"
                : "Sem prompt gerado.";

            card.innerHTML = `
                <div class="storyboardTop">
                    <strong>${index + 1}. ${UI.escape(scene.title)}</strong>
                    <span>${scene.duration}s</span>
                </div>
                <div class="storyboardThumb"></div>
                <p class="storyboardPromptPreview">${promptPreview}</p>
                <div class="storyboardButtons">
                    <input type="file" accept="image/*" class="storyboardFileInput" hidden>
                    <button class="storyboardAttach">${image ? "🔄 Substituir" : "📎 Anexar imagem"}</button>
                    ${image ? '<button class="storyboardRemove btnDanger">🗑 Remover</button>' : ""}
                </div>
            `;

            const thumb = card.querySelector(".storyboardThumb");

            if (image && image.blob) {

                const url = URL.createObjectURL(image.blob);
                const imgEl = document.createElement("img");

                imgEl.src = url;

                thumb.appendChild(imgEl);

            }

            else {

                thumb.innerHTML =
                    '<span class="storyboardEmpty">Sem imagem</span>';

            }

            const fileInput = card.querySelector(
                ".storyboardFileInput"
            );

            card.querySelector(".storyboardAttach")
                .onclick = () => {

                    fileInput.click();

                };

            fileInput.onchange = async (event) => {

                const file = event.target.files[0];

                fileInput.value = "";

                if (!file) return;

                UI.showLoading("Anexando imagem...");

                await this.attachImage(
                    Projects.current.id,
                    scene.id,
                    file
                );

                UI.hideLoading();

                this.render();
                UI.updateDashboard();
                UI.toast("Imagem anexada.");

            };

            const removeBtn = card.querySelector(
                ".storyboardRemove"
            );

            if (removeBtn) {

                removeBtn.onclick = async () => {

                    await this.removeImagesForScene(
                        Projects.current.id,
                        scene.id
                    );

                    this.render();
                    UI.updateDashboard();
                    UI.toast("Imagem removida.");

                };

            }

            el.appendChild(card);

        });

    }

};
