/* =====================================================
   Stick Studio AI — js/editor/animation.js
   NÃO IMPLEMENTADO NESTA VERSÃO.

   A montagem final do vídeo (transições, áudio,
   legendas) continua sendo feita no CapCut, fora do
   app. A exportação em js/editor/export.js prepara as
   imagens já renomeadas e na ordem certa (mais um
   manifesto com a duração de cada cena) para facilitar
   essa montagem.

   Ideia para uma v2: pré-visualizar a animação (as
   imagens do Storyboard em sequência, no tempo de cada
   cena) direto no navegador, antes de exportar.
===================================================== */
