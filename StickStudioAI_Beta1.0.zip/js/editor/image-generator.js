/* =====================================================
   Stick Studio AI — js/editor/image-generator.js
   NÃO IMPLEMENTADO NESTA VERSÃO.

   O fluxo atual é manual, e é assim de propósito: os
   prompts gerados pelo Diretor IA são usados nas
   ferramentas externas de geração de imagem (Meta AI,
   Meta AI Vibes, Google Flow etc.) e o resultado é
   anexado a cada cena na tela Storyboard
   (js/editor/storyboard.js).

   Ideia para uma v2: chamar a API de alguma dessas
   ferramentas diretamente daqui, para gerar a imagem sem
   sair do app — hoje isso exigiria chave de API própria
   de cada serviço e não é feito automaticamente.
===================================================== */
