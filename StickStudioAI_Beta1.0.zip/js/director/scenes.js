/* =====================================================
   Stick Studio AI
   scenes.js
===================================================== */

const Scenes = {

    list: [],

    clear() {

        this.list = [];

    },

    process(text) {

        this.clear();

        if (!text) return;

        const lines = text
            .split("\n")
            .map(l => l.trim())
            .filter(l => l.length);

        let index = 1;

        let current = null;

        lines.forEach(line => {

            if (
                line.toLowerCase().startsWith("cena")
            ) {

                if (current) {

                    this.list.push(current);

                }

                current = {
                    id: index,
                    title: line,
                    text: "",
                    duration: 0,
                    durationOverride: null
                };

                index++;

            }

            else {

                if (!current) {

                    current = {
                        id: index,
                        title: "Cena 1",
                        text: "",
                        duration: 0,
                        durationOverride: null
                    };

                }

                current.text += line + " ";

            }

        });

        if (current) {

            current.duration =
                this.estimateDuration(
                    current.text
                );

            this.list.push(current);

        }

    },

    estimateDuration(text) {

        if (!text) return 0;

        const words = text
            .trim()
            .split(/\s+/)
            .length;

        /* Aproximadamente 150 palavras/minuto */

        const seconds = Math.ceil(
            (words / 150) * 60
        );

        return Math.max(3, seconds);

    },

    getAll() {

        return this.list;

    },

    get(id) {

        return this.list.find(scene =>
            scene.id === id
        );

    },

    count() {

        return this.list.length;

    },

    totalDuration() {

        return this.list.reduce(
            (total, scene) => {

                return total +
                    (scene.duration || 0);

            },
            0
        );

    },

    remove(id) {

        this.list =
            this.list.filter(scene =>
                scene.id !== id
            );

    },

    update(id, data) {

        const scene =
            this.get(id);

        if (!scene) return;

        Object.assign(scene, data);

    },

    setDuration(id, seconds) {

        const scene = this.get(id);

        if (!scene) return false;

        const value = Number(seconds);

        if (!value || value <= 0) return false;

        scene.durationOverride = value;
        scene.duration = value;

        return true;

    },

    move(id, direction) {

        const index = this.list.findIndex(
            scene => scene.id === id
        );

        if (index === -1) return false;

        const target = index + direction;

        if (target < 0 || target >= this.list.length) {

            return false;

        }

        const temp = this.list[index];

        this.list[index] = this.list[target];
        this.list[target] = temp;

        return true;

    },

    add(title, text = "") {

        const nextId =
            this.list.length
            ? Math.max(...this.list.map(s => s.id)) + 1
            : 1;

        const scene = {
            id: nextId,
            title,
            text,
            duration:
                this.estimateDuration(text) || 3,
            durationOverride: null
        };

        this.list.push(scene);

        return scene;

    },

    export() {

        return JSON.parse(
            JSON.stringify(this.list)
        );

    },

    /* ==========================================
       PERSISTÊNCIA
    ========================================== */

    async save(projectId) {

        if (!projectId) return false;

        return ProjectData.set(
            "scenes",
            projectId,
            this.list
        );

    },

    async load(projectId) {

        if (!projectId) {

            this.clear();
            return this.list;

        }

        const data = await ProjectData.get(
            "scenes",
            projectId
        );

        this.list = data || [];

        return this.list;

    }

};
