/* =====================================================
   Stick Studio AI
   transcription.js
===================================================== */

const Transcription = {

    text: "",

    language: "pt-BR",

    status: "idle",

    async process(audio) {

        this.status = "processing";

        UI.toast("Iniciando transcrição...");

        try {

            if (!audio) {

                throw new Error("Nenhum áudio encontrado.");

            }

            /*
             * FUTURO:
             * Aqui será chamada a API de IA
             * (Whisper, Gemini, OpenAI etc.)
             * Até lá, use "Transcrever (simulado)" para
             * um texto de teste, ou cole a transcrição
             * manualmente na tela de Roteiro.
             */

            const text = await this.simulate(audio);

            this.setManual(text);

            console.log("Transcrição concluída.");

            return this.text;

        } catch (e) {

            this.status = "error";
            console.error(e);
            alert(e.message);

        }

    },

    simulate(audio) {

        return new Promise((resolve) => {

            setTimeout(() => {

                resolve(
`[TRANSCRIÇÃO SIMULADA]

Arquivo:
${audio.name}

Duração:
${Utils.formatTime(audio.duration)}

A transcrição automática real ainda não está
disponível nesta versão. Cole o texto real
usando o campo "Colar transcrição" na tela de
Roteiro, ou edite este texto manualmente.`
                );

            }, 900);

        });

    },

    /* ==========================================
       EDIÇÃO MANUAL
    ========================================== */

    setManual(text) {

        this.text = (text || "").trim();
        this.status = this.text ? "finished" : "idle";

        if (Projects.current) {

            Projects.updateCurrent({
                transcriptionText: this.text
            });

        }

        return this.text;

    },

    /* ==========================================
       PERSISTÊNCIA
    ========================================== */

    hydrate(project) {

        this.text = project.transcriptionText || "";
        this.status = this.text ? "finished" : "idle";

    },

    getText() {

        return this.text;

    },

    clear() {

        this.text = "";
        this.status = "idle";

    }

};
