/* =====================================================
   Stick Studio AI
   director.js
   Diretor Inteligente
===================================================== */

const Director = {

    projectId: null,

    story: "",

    async start(projectId) {

        this.projectId = projectId;

        console.log("Diretor iniciado.");

        await this.loadStory();

        if (!this.story) {

            alert("Nenhuma história encontrada.");
            return;

        }

        await this.process();

    },

    async loadStory() {

        if (Story.getSource() === "manual") {

            this.story = Story.getText();
            return;

        }

        /* Fonte = áudio: usa transcrição já salva/colada,
           ou dispara a transcrição (simulada) do áudio
           principal caso ainda não exista nenhuma. */

        if (Transcription.getText()) {

            this.story = Transcription.getText();
            Story.setText(this.story);
            return;

        }

        const audio = AudioManager.getMainAudio();

        if (!audio) {

            this.story = "";
            return;

        }

        const text = await Transcription.process(audio);

        Story.setText(text);

        this.story = text;

    },

    async process() {

        console.log("Processando história...");

        this.createScenes();
        this.detectCharacters();
        this.detectLocations();
        this.detectObjects();
        this.createPrompts();
        this.createTimeline();

        await this.persistAll();

    },

    /* ==========================================
       CENAS
    ========================================== */

    createScenes() {

        if (
            typeof Scenes === "undefined" ||
            typeof Scenes.process !== "function"
        ) {
            return;
        }

        Scenes.process(this.story);

    },

    /* ==========================================
       PERSONAGENS
    ========================================== */

    detectCharacters() {

        if (
            typeof Characters === "undefined" ||
            typeof Characters.process !== "function"
        ) {
            return;
        }

        Characters.process(this.story);

    },

    /* ==========================================
       CENÁRIOS
    ========================================== */

    detectLocations() {

        if (
            typeof Locations === "undefined" ||
            typeof Locations.process !== "function"
        ) {
            return;
        }

        Locations.process(this.story);

    },

    /* ==========================================
       OBJETOS
    ========================================== */

    detectObjects() {

        if (
            typeof Objects === "undefined" ||
            typeof Objects.process !== "function"
        ) {
            return;
        }

        Objects.process(this.story);

    },

    /* ==========================================
       PROMPTS
    ========================================== */

    createPrompts() {

        if (
            typeof Prompts === "undefined" ||
            typeof Prompts.process !== "function"
        ) {
            return;
        }

        Prompts.process();

    },

    /* ==========================================
       TIMELINE
    ========================================== */

    createTimeline() {

        if (
            typeof Timeline === "undefined" ||
            typeof Timeline.build !== "function"
        ) {
            return;
        }

        Timeline.build();

    },

    /* ==========================================
       PERSISTÊNCIA
    ========================================== */

    async persistAll() {

        if (!this.projectId) return;

        await Promise.all([
            Scenes.save(this.projectId),
            Characters.save(this.projectId),
            Locations.save(this.projectId),
            Objects.save(this.projectId),
            Prompts.save(this.projectId)
        ]);

        if (typeof Projects !== "undefined") {

            await Projects.update(this.projectId, {
                status: "Analisado"
            });

        }

    },

    async loadForProject(projectId) {

        this.projectId = projectId;

        if (!projectId) {

            Scenes.clear();
            Characters.clear();
            Locations.clear();
            Objects.clear();
            Prompts.clear();
            Timeline.clear();
            return;

        }

        await Promise.all([
            Scenes.load(projectId),
            Characters.load(projectId),
            Locations.load(projectId),
            Objects.load(projectId),
            Prompts.load(projectId)
        ]);

        Timeline.build();

    },

    /* ==========================================
       ATUALIZAR PROMPTS (sem reanalisar tudo)
    ========================================== */

    async refreshPrompts() {

        if (!this.projectId) {

            alert("Nenhum projeto aberto.");
            return;

        }

        Prompts.process();

        await Prompts.save(this.projectId);

        if (typeof UI !== "undefined") {

            UI.renderPrompts();

            if (typeof UI.renderPromptsPage === "function") {

                UI.renderPromptsPage();

            }

            UI.toast("Prompts atualizados.");

        }

    },

    /* ==========================================
       FINALIZAÇÃO
    ========================================== */

    finish() {

        console.log("Diretor finalizado.");

        if (
            typeof UI !== "undefined" &&
            typeof UI.renderDirector === "function"
        ) {

            UI.renderDirector();

        }

        if (
            typeof UI !== "undefined" &&
            typeof UI.updateDashboard === "function"
        ) {

            UI.updateDashboard();

        }

        if (
            typeof UI !== "undefined" &&
            typeof UI.toast === "function"
        ) {

            UI.toast("Projeto analisado com sucesso.");

        }

    },

    reset() {

        this.projectId = null;
        this.story = "";

    },

    async reanalyze() {

        if (!Projects.current) {

            alert("Nenhum projeto aberto.");
            return;

        }

        const projectId = Projects.current.id;

        this.reset();

        await this.start(projectId);

    },

    getStory() {

        return this.story;

    },

    hasStory() {

        return this.story.trim().length > 0;

    }

};

/* ==========================================
   HOOK AUTOMÁTICO
========================================== */

const __directorStart = Director.start;

Director.start = async function (projectId) {

    try {

        await __directorStart.call(this, projectId);

        this.finish();

    }

    catch (error) {

        console.error(error);

        if (typeof UI !== "undefined") {

            UI.hideLoading();
            UI.toast("Erro durante a análise.");

        }

    }

};
