/* =====================================================
   Stick Studio AI
   timeline.js
   Timeline Inteligente
===================================================== */

const Timeline = {

    scenes: [],

    mode: "auto", // auto | manual

    fps: 24,

    build() {

        this.scenes = [];

        const list = Scenes.getAll();

        let currentTime = 0;

        list.forEach(scene => {

            const duration = this.calculate(scene);

            this.scenes.push({
                id: scene.id,
                title: scene.title,
                start: currentTime,
                end: currentTime + duration,
                duration,
                fps: this.fps,
                transition: "cut",
                locked: false,
                scene
            });

            currentTime += duration;

        });

        return this.scenes;

    },

    /* Alias mantido por compatibilidade com versões
       anteriores do Diretor. */
    generate() {

        return this.build();

    },

    calculate(scene) {

        if (
            scene.durationOverride &&
            scene.durationOverride > 0
        ) {

            return scene.durationOverride;

        }

        return this.autoDuration(scene);

    },

    autoDuration(scene) {

        const words = (scene.text || "")
            .split(/\s+/)
            .filter(Boolean).length;

        let seconds = Math.ceil(words / 3);

        if (seconds < 3) seconds = 3;
        if (seconds > 15) seconds = 15;

        return seconds;

    },

    setDuration(sceneId, seconds) {

        const ok = Scenes.setDuration(sceneId, seconds);

        if (!ok) return false;

        this.build();

        return true;

    },

    recalculate() {

        let current = 0;

        this.scenes.forEach(scene => {

            scene.start = current;
            scene.end = current + scene.duration;
            current = scene.end;

        });

    },

    totalDuration() {

        if (!this.scenes.length) return 0;

        return this.scenes[
            this.scenes.length - 1
        ].end;

    },

    setMode(mode) {

        this.mode = mode;
        this.build();

    },

    getAll() {

        return this.scenes;

    },

    get(id) {

        return this.scenes.find(
            scene => scene.id === id
        );

    },

    clear() {

        this.scenes = [];

    }

};
