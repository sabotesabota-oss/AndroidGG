/* =====================================================
   Stick Studio AI
   characters.js
   Memória de Personagens
===================================================== */

const Characters = {

    list: [],

    async process() {

        this.clear();

        const scenes = Scenes.getAll();

        scenes.forEach(scene => {

            this.extract(scene);

        });

        console.log(
            this.list.length +
            " personagem(ns) encontrado(s)."
        );

        return this.list;

    },

    extract(scene) {

        const words = scene.text.match(
            /\b[A-ZÀ-Ú][a-zà-ú]+\b/g
        ) || [];

        words.forEach(name => {

            if (this.exists(name)) {

                this.addScene(name, scene.id);
                return;

            }

            this.list.push({
                id: this.nextId(),
                name: name,
                description: "",
                age: "",
                gender: "",
                appearance: {
                    hair: "",
                    eyes: "",
                    clothes: "",
                    colors: ""
                },
                expressions: [],
                scenes: [scene.id],
                manual: false
            });

        });

    },

    nextId() {

        return this.list.length
            ? Math.max(...this.list.map(c => c.id)) + 1
            : 1;

    },

    exists(name) {

        return this.list.some(
            character =>
                character.name.toLowerCase() ===
                name.toLowerCase()
        );

    },

    addScene(characterName, sceneId) {

        const character = this.list.find(
            c => c.name.toLowerCase() ===
                characterName.toLowerCase()
        );

        if (!character) return;

        if (!character.scenes.includes(sceneId)) {

            character.scenes.push(sceneId);

        }

    },

    add(data) {

        const character = {
            id: this.nextId(),
            name: data.name || "Sem nome",
            description: data.description || "",
            age: data.age || "",
            gender: data.gender || "",
            appearance: {
                hair: data.hair || "",
                eyes: data.eyes || "",
                clothes: data.clothes || "",
                colors: data.colors || ""
            },
            expressions: [],
            scenes: [],
            manual: true
        };

        this.list.push(character);

        return character;

    },

    update(id, data) {

        const character = this.list.find(
            c => c.id === id
        );

        if (!character) return null;

        character.name = data.name || character.name;
        character.description = data.description || "";
        character.age = data.age || "";
        character.gender = data.gender || "";

        character.appearance = {
            hair: data.hair || "",
            eyes: data.eyes || "",
            clothes: data.clothes || "",
            colors: data.colors || ""
        };

        return character;

    },

    remove(id) {

        this.list = this.list.filter(
            c => c.id !== id
        );

    },

    getAll() {

        return this.list;

    },

    get(id) {

        return this.list.find(
            character => character.id === id
        );

    },

    getByName(name) {

        return this.list.find(
            character =>
                character.name.toLowerCase() ===
                name.toLowerCase()
        );

    },

    clear() {

        this.list = [];

    },

    /* ==========================================
       PERSISTÊNCIA
    ========================================== */

    async save(projectId) {

        if (!projectId) return false;

        return ProjectData.set(
            "characters",
            projectId,
            this.list
        );

    },

    async load(projectId) {

        if (!projectId) {

            this.clear();
            return this.list;

        }

        const data = await ProjectData.get(
            "characters",
            projectId
        );

        this.list = data || [];

        return this.list;

    }

};
