/* =====================================================
   Stick Studio AI
   objects.js
   Memória de Objetos
===================================================== */

const Objects = {

    list: [],

    async process() {

        this.clear();

        const scenes = Scenes.getAll();

        scenes.forEach(scene => {

            this.extract(scene);

        });

        console.log(
            this.list.length +
            " objeto(s) encontrado(s)."
        );

        return this.list;

    },

    extract(scene) {

        const keywords = [
            "espada", "escudo", "livro", "mochila",
            "celular", "telefone", "carro", "moto",
            "bicicleta", "arma", "revólver", "pistola",
            "arco", "flecha", "machado", "martelo",
            "chave", "porta", "janela", "mesa",
            "cadeira", "computador", "notebook",
            "televisão", "tv", "microfone", "câmera",
            "lanterna", "mapa", "caixa"
        ];

        const text = scene.text.toLowerCase();

        keywords.forEach(object => {

            if (!text.includes(object)) return;

            if (this.existsByName(object)) {

                this.addScene(object, scene.id);
                return;

            }

            this.list.push({
                id: this.nextId(),
                name: object,
                description: "",
                category: "",
                color: "",
                style: "",
                scenes: [scene.id],
                manual: false
            });

        });

    },

    nextId() {

        return this.list.length
            ? Math.max(...this.list.map(o => o.id)) + 1
            : 1;

    },

    existsByName(name) {

        return this.list.some(
            object => object.name.toLowerCase() ===
                name.toLowerCase()
        );

    },

    addScene(name, sceneId) {

        const object = this.list.find(
            item => item.name.toLowerCase() ===
                name.toLowerCase()
        );

        if (!object) return;

        if (!object.scenes.includes(sceneId)) {

            object.scenes.push(sceneId);

        }

    },

    add(data) {

        const object = {
            id: this.nextId(),
            name: data.name || "Sem nome",
            description: data.description || "",
            category: data.category || "",
            color: data.color || "",
            style: data.style || "",
            scenes: [],
            manual: true
        };

        this.list.push(object);

        return object;

    },

    update(id, data) {

        const object = this.list.find(
            o => o.id === id
        );

        if (!object) return null;

        object.name = data.name || object.name;
        object.description = data.description || "";
        object.category = data.category || "";
        object.color = data.color || "";
        object.style = data.style || "";

        return object;

    },

    remove(id) {

        this.list = this.list.filter(
            o => o.id !== id
        );

    },

    getAll() {

        return this.list;

    },

    get(id) {

        return this.list.find(
            object => object.id === id
        );

    },

    clear() {

        this.list = [];

    },

    /* ==========================================
       PERSISTÊNCIA
    ========================================== */

    async save(projectId) {

        if (!projectId) return false;

        return ProjectData.set(
            "objects",
            projectId,
            this.list
        );

    },

    async load(projectId) {

        if (!projectId) {

            this.clear();
            return this.list;

        }

        const data = await ProjectData.get(
            "objects",
            projectId
        );

        this.list = data || [];

        return this.list;

    }

};
