/* =====================================================
   Stick Studio AI
   locations.js
   Memória de Cenários
===================================================== */

const Locations = {

    list: [],

    async process() {

        this.clear();

        const scenes = Scenes.getAll();

        scenes.forEach(scene => {

            this.extract(scene);

        });

        console.log(
            this.list.length +
            " cenário(s) encontrado(s)."
        );

        return this.list;

    },

    extract(scene) {

        const keywords = [
            "floresta", "cidade", "castelo", "casa",
            "quarto", "escola", "praia", "parque",
            "rua", "montanha", "rio", "lago",
            "deserto", "igreja", "hospital", "mercado",
            "fazenda", "vila", "oceano", "caverna"
        ];

        const text = scene.text.toLowerCase();

        keywords.forEach(location => {

            if (!text.includes(location)) return;

            if (this.existsByName(location)) {

                this.addScene(location, scene.id);
                return;

            }

            this.list.push({
                id: this.nextId(),
                name: location,
                description: "",
                style: "",
                lighting: "",
                weather: "",
                scenes: [scene.id],
                manual: false
            });

        });

    },

    nextId() {

        return this.list.length
            ? Math.max(...this.list.map(l => l.id)) + 1
            : 1;

    },

    existsByName(name) {

        return this.list.some(
            location =>
                location.name.toLowerCase() ===
                name.toLowerCase()
        );

    },

    addScene(name, sceneId) {

        const location = this.list.find(
            item => item.name.toLowerCase() ===
                name.toLowerCase()
        );

        if (!location) return;

        if (!location.scenes.includes(sceneId)) {

            location.scenes.push(sceneId);

        }

    },

    add(data) {

        const location = {
            id: this.nextId(),
            name: data.name || "Sem nome",
            description: data.description || "",
            style: data.style || "",
            lighting: data.lighting || "",
            weather: data.weather || "",
            scenes: [],
            manual: true
        };

        this.list.push(location);

        return location;

    },

    update(id, data) {

        const location = this.list.find(
            l => l.id === id
        );

        if (!location) return null;

        location.name = data.name || location.name;
        location.description = data.description || "";
        location.style = data.style || "";
        location.lighting = data.lighting || "";
        location.weather = data.weather || "";

        return location;

    },

    remove(id) {

        this.list = this.list.filter(
            l => l.id !== id
        );

    },

    getAll() {

        return this.list;

    },

    get(id) {

        return this.list.find(
            location => location.id === id
        );

    },

    clear() {

        this.list = [];

    },

    /* ==========================================
       PERSISTÊNCIA
    ========================================== */

    async save(projectId) {

        if (!projectId) return false;

        return ProjectData.set(
            "locations",
            projectId,
            this.list
        );

    },

    async load(projectId) {

        if (!projectId) {

            this.clear();
            return this.list;

        }

        const data = await ProjectData.get(
            "locations",
            projectId
        );

        this.list = data || [];

        return this.list;

    }

};
