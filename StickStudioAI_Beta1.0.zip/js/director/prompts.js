/* =====================================================
   Stick Studio AI
   prompts.js
   Gerador de Prompts
===================================================== */

const Prompts = {

    list: [],

    async process() {

        const previous = this.list;

        this.list = [];

        const scenes = Scenes.getAll();

        scenes.forEach(scene => {

            const prev = previous.find(
                p => p.sceneId === scene.id
            );

            /* Prompts editados manualmente são preservados */

            if (prev && prev.edited) {

                this.list.push(prev);
                return;

            }

            this.list.push({
                id: scene.id,
                sceneId: scene.id,
                prompt: this.build(scene),
                used: prev ? prev.used : false,
                edited: false
            });

        });

        console.log(
            this.list.length +
            " prompt(s) criado(s)."
        );

        return this.list;

    },

    build(scene) {

        const characters = Characters.getAll()
            .filter(character =>
                character.scenes.includes(scene.id)
            );

        const locations = Locations.getAll()
            .filter(location =>
                location.scenes.includes(scene.id)
            );

        const objects = Objects.getAll()
            .filter(object =>
                object.scenes.includes(scene.id)
            );

        const characterLines = characters.length
            ? characters.map(c => this.describeCharacter(c)).join("\n")
            : "Nenhum";

        const locationLines = locations.length
            ? locations.map(l => this.describeLocation(l)).join("\n")
            : "Nenhum";

        const objectLines = objects.length
            ? objects.map(o => this.describeObject(o)).join("\n")
            : "Nenhum";

        return `

Cena ${scene.id}

Descrição:
${scene.text.trim()}

Personagens:
${characterLines}

Cenários:
${locationLines}

Objetos:
${objectLines}

Estilo:
Stick Figure Animation

Qualidade:
Alta

Manter consistência visual dos personagens,
cenários e objetos entre todas as cenas.

`.trim();

    },

    describeCharacter(character) {

        const details = [];

        if (character.description) {

            details.push(character.description);

        }

        const appearance = character.appearance || {};

        const traits = [
            appearance.hair,
            appearance.eyes,
            appearance.clothes,
            appearance.colors
        ].filter(Boolean);

        if (traits.length) {

            details.push(traits.join(", "));

        }

        if (character.age) {

            details.push(character.age + " anos");

        }

        if (!details.length) {

            return "- " + character.name;

        }

        return "- " + character.name + " — " +
            details.join(" — ");

    },

    describeLocation(location) {

        const details = [
            location.description,
            location.style,
            location.lighting,
            location.weather
        ].filter(Boolean);

        if (!details.length) {

            return "- " + location.name;

        }

        return "- " + location.name + " — " +
            details.join(", ");

    },

    describeObject(object) {

        const details = [
            object.description,
            object.category,
            object.color,
            object.style
        ].filter(Boolean);

        if (!details.length) {

            return "- " + object.name;

        }

        return "- " + object.name + " — " +
            details.join(", ");

    },

    /* ==========================================
       EDIÇÃO
    ========================================== */

    update(id, text) {

        const item = this.get(id);

        if (!item) return null;

        item.prompt = text;
        item.edited = true;

        return item;

    },

    toggleUsed(id) {

        const item = this.get(id);

        if (!item) return null;

        item.used = !item.used;

        return item;

    },

    remove(id) {

        this.list = this.list.filter(
            item => item.id !== id
        );

    },

    get(sceneId) {

        return this.list.find(
            prompt =>
                prompt.sceneId === sceneId ||
                prompt.id === sceneId
        );

    },

    getAll() {

        return this.list;

    },

    clear() {

        this.list = [];

    },

    /* ==========================================
       PERSISTÊNCIA
    ========================================== */

    async save(projectId) {

        if (!projectId) return false;

        return ProjectData.set(
            "prompts",
            projectId,
            this.list
        );

    },

    async load(projectId) {

        if (!projectId) {

            this.clear();
            return this.list;

        }

        const data = await ProjectData.get(
            "prompts",
            projectId
        );

        this.list = data || [];

        return this.list;

    }

};
