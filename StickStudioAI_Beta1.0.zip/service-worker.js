/* =====================================================
   Stick Studio AI
   service-worker.js
   Cache do app shell para uso offline (PWA)
===================================================== */

const CACHE_NAME = "stickstudio-v100";

const FILES = [
  "./",
  "./index.html",
  "./manifest.json",
  "./favicon.ico",

  "./css/app.css",

  "./js/vendor/zip-writer.js",

  "./js/core/database-upgrade.js",
  "./js/core/database.js",
  "./js/core/project-data.js",
  "./js/core/utils.js",
  "./js/core/ui.js",
  "./js/core/navigation.js",
  "./js/core/app.js",

  "./js/project/projects.js",
  "./js/project/audio.js",
  "./js/project/story.js",

  "./js/director/transcription.js",
  "./js/director/scenes.js",
  "./js/director/timeline.js",
  "./js/director/characters.js",
  "./js/director/locations.js",
  "./js/director/objects.js",
  "./js/director/prompts.js",
  "./js/director/director.js",

  "./js/editor/storyboard.js",
  "./js/editor/export.js",

  "./assets/icons/icon-192.png",
  "./assets/icons/icon-512.png",
  "./assets/icons/icon-512-maskable.png"
];

self.addEventListener("install", (event) => {

  self.skipWaiting();

  event.waitUntil(

    caches.open(CACHE_NAME).then((cache) => {

      return cache.addAll(FILES).catch((error) => {

        console.warn("Falha ao cachear app shell:", error);

      });

    })

  );

});

self.addEventListener("activate", (event) => {

  event.waitUntil(

    caches.keys().then((names) => {

      return Promise.all(

        names
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))

      );

    }).then(() => self.clients.claim())

  );

});

self.addEventListener("fetch", (event) => {

  if (event.request.method !== "GET") return;

  event.respondWith(

    caches.match(event.request).then((cached) => {

      if (cached) return cached;

      return fetch(event.request)
        .then((response) => {

          if (
            response &&
            response.status === 200 &&
            response.type === "basic"
          ) {

            const copy = response.clone();

            caches.open(CACHE_NAME).then((cache) => {

              cache.put(event.request, copy);

            });

          }

          return response;

        })
        .catch(() => {

          if (event.request.mode === "navigate") {

            return caches.match("./index.html");

          }

        });

    })

  );

});
