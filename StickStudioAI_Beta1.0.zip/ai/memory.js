/* =====================================================
   Stick Studio AI — ai/memory.js
   RESERVADO PARA VERSÃO FUTURA COM IA REAL.

   Hoje a "memória" de personagens/cenários/objetos entre
   cenas é apenas a lista salva em cada projeto (ver
   js/core/project-data.js). Este arquivo não é carregado
   pelo index.html.

   Ideia para uma v2: manter um "guia de estilo visual" do
   projeto (referências de imagem por personagem/cenário)
   para reforçar a consistência entre as gerações de
   imagem em diferentes ferramentas de IA.
===================================================== */
