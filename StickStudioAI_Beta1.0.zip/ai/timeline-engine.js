/* =====================================================
   Stick Studio AI — ai/timeline-engine.js
   RESERVADO PARA VERSÃO FUTURA COM IA REAL.

   Hoje o cálculo de duração de cada cena é feito por
   js/director/timeline.js, estimando por número de
   palavras (ou usando a duração definida manualmente na
   tela Timeline). Este arquivo não é carregado pelo
   index.html.

   Ideia para uma v2: sincronizar a timeline com a
   duração real do áudio principal (usando marcação de
   tempo por trecho transcrito), em vez de estimar pelo
   texto.
===================================================== */
