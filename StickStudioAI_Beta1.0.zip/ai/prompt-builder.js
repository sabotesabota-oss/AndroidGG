/* =====================================================
   Stick Studio AI — ai/prompt-builder.js
   RESERVADO PARA VERSÃO FUTURA COM IA REAL.

   Hoje a montagem do prompt de cada cena é feita por
   Prompts.build() em js/director/prompts.js, combinando
   o texto da cena com as descrições salvas de
   personagens, cenários e objetos. Este arquivo não é
   carregado pelo index.html.

   Ideia para uma v2: usar um modelo de linguagem para
   reescrever e otimizar o prompt final para a ferramenta
   de geração de imagem escolhida (Meta AI, Flow etc.),
   mantendo a consistência visual entre cenas.
===================================================== */
