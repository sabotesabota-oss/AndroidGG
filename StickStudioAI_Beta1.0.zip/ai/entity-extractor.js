/* =====================================================
   Stick Studio AI — ai/entity-extractor.js
   RESERVADO PARA VERSÃO FUTURA COM IA REAL.

   Hoje a extração de personagens (regex de palavras
   capitalizadas) e de cenários/objetos (lista fixa de
   palavras-chave) é feita por js/director/characters.js,
   locations.js e objects.js. Este arquivo não é
   carregado pelo index.html.

   Ideia para uma v2: usar um modelo de linguagem para
   reconhecer personagens, cenários e objetos citados no
   roteiro sem depender de listas fixas — funcionando bem
   mesmo para roteiros com vocabulário fora da lista atual.
===================================================== */
