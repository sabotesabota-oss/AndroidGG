/* =====================================================
   Stick Studio AI — ai/director-engine.js
   RESERVADO PARA VERSÃO FUTURA COM IA REAL.

   Hoje quem faz esse trabalho é js/director/director.js,
   usando heurísticas simples (regex + palavras-chave).
   Este arquivo não é carregado pelo index.html.

   Ideia para uma v2: substituir Director.process() por
   uma chamada a um modelo de linguagem (ex.: via API),
   enviando o roteiro completo e recebendo de volta cenas,
   personagens, cenários, objetos e prompts já estruturados
   e com descrições visuais consistentes — sem depender de
   listas fixas de palavras-chave.
===================================================== */
