/* =====================================================
   Stick Studio AI — ai/scenes-splitter.js
   RESERVADO PARA VERSÃO FUTURA COM IA REAL.

   Hoje a divisão de cenas é feita por
   js/director/scenes.js, quebrando o texto sempre que
   uma linha começa com a palavra "Cena". Este arquivo
   não é carregado pelo index.html.

   Ideia para uma v2: usar um modelo de linguagem para
   dividir o roteiro em cenas de forma semântica, mesmo
   quando o autor não escreve "Cena 1", "Cena 2" etc.
===================================================== */
